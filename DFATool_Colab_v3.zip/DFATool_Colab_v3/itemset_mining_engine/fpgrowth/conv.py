import os
import sys
import shutil
import time
import re
import math
import getopt
import collections
import glob
import warnings
import networkx as nx

def pause():
	programPause = input("Press the <ENTER> key to continue...")


filename = "clefia5.tab"
outfilename = "clefia5_mod.tab"
linelist =  open(filename, 'rU').read().splitlines() 
linelist = list(filter(None, linelist))
linelist_mod = []

#Check for all 0 columns
zerocols = []
varcount = 0

for line in linelist:
	delimiters = ",", " ", "+"
	regexPattern = '|'.join(map(re.escape, delimiters))
	llist = re.split(regexPattern, line)
	tokens1 = list(filter(None, llist))
	varcount = len(tokens1)

colsum = [0]*varcount

for line in linelist:
	delimiters = ",", " ", "+"
	regexPattern = '|'.join(map(re.escape, delimiters))
	llist = re.split(regexPattern, line)
	tokens1 = list(filter(None, llist))
	for v in range(varcount):
		colsum[v] = colsum[v] + int(tokens1[v])
		

for line in linelist:
	delimiters = ",", " ", "+"
	regexPattern = '|'.join(map(re.escape, delimiters))
	llist = re.split(regexPattern, line)
	tokens1 = list(filter(None, llist))
	varcount = len(tokens1)
	mod_line = ''
	for v in range(varcount):
		if ( not(colsum[v] == 0) ):
			tmp = "V"+ str(v) + "=" + str(tokens1[v])
			if (v == (varcount-1)):		
				mod_line = mod_line + tmp + "\n"
			else:
				mod_line = mod_line + tmp + ","	
	linelist_mod.append(mod_line)

outf = open(outfilename, "w")
for l in linelist_mod:
	outf.write(l)
outf.close()		
