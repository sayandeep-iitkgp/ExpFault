import os
import sys
import shutil
import time
import re
import math
import getopt
import collections
import glob
import warnings
import networkx as nx
import subprocess

def pause():
	programPause = input("Press the <ENTER> key to continue...")


ip_folder_1 = "arff/"
filename_list_arff = []
for file in os.listdir(ip_folder_1):
	if file.endswith(".arff"):
		filename_list_arff.append(os.path.join(ip_folder_1, file))

for filename in filename_list_arff:
	print(filename)
	linelist_mod = []
	data = []
	zerocols = []
	varcount = 0
	
	fname = filename
	fname = fname[5:]
	fname = fname[:-5]
	outfilename = fname + '.tab'
	outfilename = 'tabfiles/' + outfilename
	
	linelist =  open(filename, 'rU').read().splitlines() 
	linelist = list(filter(None, linelist))
	startflag = False
	for line in linelist:
		if (line.startswith('@data')):
			startflag = True
			continue
		if (startflag):
			data.append(line)
	for line in data:
		delimiters = ",", " ", "+"
		regexPattern = '|'.join(map(re.escape, delimiters))
		llist = re.split(regexPattern, line)
		tokens1 = list(filter(None, llist))
		varcount = len(tokens1)	
	colsum = [0]*varcount
	
	for line in data:
		delimiters = ",", " ", "+"
		regexPattern = '|'.join(map(re.escape, delimiters))
		llist = re.split(regexPattern, line)
		tokens1 = list(filter(None, llist))
		for v in range(varcount):
			colsum[v] = colsum[v] + int(tokens1[v])	

	for line in data:
		delimiters = ",", " ", "+"
		regexPattern = '|'.join(map(re.escape, delimiters))
		llist = re.split(regexPattern, line)
		tokens1 = list(filter(None, llist))
		varcount = len(tokens1)
		mod_line = ''
		for v in range(varcount):
			if ( not(colsum[v] == 0) ):
				tmp = "V"+ str(v) + "=" + str(tokens1[v])
				mod_line = mod_line + tmp + ' '
		mod_line = mod_line + '\n'		 	
		linelist_mod.append(mod_line)
	outf = open(outfilename, "w")
	for l in linelist_mod:
		outf.write(l)
	outf.close()

pause()

ip_folder_2 = "tabfiles/"
op_folder = "results/"
filename_list_tab = []
for file in os.listdir(ip_folder_2):
	if file.endswith(".tab"):
		filename_list_tab.append(os.path.join(ip_folder_2, file))

for filename in filename_list_tab:
	print(filename)
	fname = filename
	fname = fname[9:]
	fname = fname[:-4]
	outfilename = fname + '.itemset'
	outfilename = op_folder + outfilename	
	#command_str = "./src/fpgrowth -tm -s0.38 -c100 -m2 -v  [%%a, ] -Z %s %s" %(filename, outfilename)
	#command_str = "./src/fpgrowth -tm -s0.38 -ec -d100 -m2 -v\" %%e\" -Z %s %s" %(filename, outfilename)
	command_str = "./src/fpgrowth -tm -s6.25 -m2 -v\" %%s\" -Z %s %s" %(filename, outfilename)
	#print(command_str)
	subprocess.call(command_str, shell=True)
	pause()

