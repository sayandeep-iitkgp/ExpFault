#!/bin/bash


# Necessary Functions
#--------------------

# Function to print a selection menu for files in a directory
selectmenu()
{	
	unset options i
	while IFS= read -r -d $'\0' f; do
	  options[i++]="$f"
	done < <(find $1/ -maxdepth 1 -type f -name "*$2" -print0 )

	select opt in "${options[@]}" "Stop the script"; do
		case $opt in *$2)
		local __result=$3 
		#echo "File $opt selected"
		echo "$opt"
		break
		# processing
		;;
		"Stop the script")
		echo "You chose to stop"
		echo ""
		break
		;;
		*)
		echo "This is not a number"
		;;
		esac
	done
}

# Check if all the files belong to the same cipher and are from same round of fault injection
# If not, return an empty string. I will check the string and raise Warning or Error messages. 
checkarfffilenames()
{
	if [  "$(ls -A $INPUTDIR)" ]; then
		#count the number of files
		local filecnt="$(ls $INPUTDIR | wc -l)"
		local check_str=""
		# Extract the cipher name and injection round number from the first file		
		for entry in "$INPUTDIR"/*
		do
			filename="$( echo "$entry" | sed -e 's#^'"$INPUTDIR"'/##' )"
			local A="$(echo "$filename" | cut -d'_' -f1)"
			local B="$(echo "$filename" | cut -d'_' -f2)"
			local C="$(echo "$filename" | cut -d'_' -f3)"
			local D="$(echo "$filename" | cut -d'_' -f4)"
			A+="_"
			check_str=$A$B
			check_str+="_"
			check_str=$check_str$C
			check_str+="_"
			check_str=$check_str$D 
			break 1
		done
		cd $INPUTDIR
		local majority_filecnt="$(ls -dq *$check_str* | wc -l)"
		cd ..
		if [  $majority_filecnt == $filecnt ]; then
			echo "$check_str"
		fi
	fi
}

								#---------------------------#
								#       Fault Simulator		#
								#---------------------------#
#echo "							#############################"
#echo "							#      FaultSim-v1.1        #"
#echo "							#                           #"
#echo "							# Author: Sayandeep Saha    #"
#echo "							#                           #"
#echo "							# Last Modified: 9/12/2017  #"
#echo "							#############################"

#echo "			Injects faults in a block cipher at a specified point and generate fault differential data"
#echo " 						   (This part is still under construction.) "
#echo " "
#echo " "
#echo " "

# Generate the .arff files for a given fault injection
# this part requires the executable code of the cipher appended with codes for
# intermediate value tracking and .arff generator. Presently, we have implemented 
# it in a cipher specific manner. Soon we will have a general cipher simulation 
# framework, where the executable can be a hardware/software code. The .arff generator 
# will be generic.  

# 											Fault simulator ends here
#---------------------------------------------------------------------------------------------------------------#

#---------------------------------------------- Logo -----------------------------------------------------------#
figlet -c -f pagga ExpFault
#---------------------------------------------------------------------------------------------------------------#

#--------------------------------------------Copy Simulation Data Interactively----------------------------------#
#source interactive_menu
#./interactive_menu
DATADIR="./arff"
CIPHERDATAFOLDER="./cipher_data"
CIPHER_DATANAME=''

# Select the cipher

echo ""
echo "Welcome!! Please select the cipher you want to analyze..."
echo ""

unset options i
for d in $CIPHERDATAFOLDER/* ; do
    [ -L "${d%/}" ] && continue
    #echo "$d"
    options[i++]="$d"
done

select opt in "${options[@]}" "Stop the script"; do
	case $opt in *$2)
	CIPHER_DATANAME=$opt 
	#echo "File $opt selected"
	#echo "$opt"
	break
	# processing
	;;
	"Stop the script")
	echo "You chose to stop"
	echo ""
	break
	;;
	*)
	echo "This is not a number"
	;;
	esac
done

if [[ $CIPHER_DATANAME = "Stop the script" ]]; then
    echo "You chose to stop. Aborting..."
    exit
fi

#echo "$CIPHER_DATANAME"

# Select the data corresponding to the cipher round and byte/nibble index

echo ""
echo "Now select round of fault injection and the byte/nibble location of the fault..."
echo "The naming convention is arff_<round_no>_<fault_width>_<byte/nibble_index>_<ciphername>"
echo "For example, \"arff_8_8_0_AES\" contains fault simulation data corresponding to an 8-bit(byte) fault"
echo "injected at the starting of the 8th round of AES. The fault corrupts the 0th byte."
echo ""

unset options2 j

for d in $CIPHER_DATANAME/* ; do
    [ -L "${d%/}" ] && continue
    #echo "$d"
    options2[j++]="$d"
done

select opt in "${options2[@]}" "Stop the script"; do
	case $opt in *$2)
	CIPHER_ROUNDDATA=$opt 
	echo "File $opt selected"
	#echo "$opt"
	break
	# processing
	;;
	"Stop the script")
	echo "You chose to stop"
	echo ""
	break
	;;
	*)
	echo "This is not a number"
	;;
	esac
done

if [[ $CIPHER_ROUNDDATA = "Stop the script" ]]; then
    echo "You chose to stop. Aborting..."
    exit
fi

#echo "$CIPHER_ROUNDDATA"

#exit


# Check if it is really a folder
 if [ -d "$CIPHER_ROUNDDATA" ]; then 
	echo "$CIPHER_ROUNDDATA"
 else 
    echo "Not a directory..Exiting..."
    exit
 fi

# Check if the target folder is empty
if [ ! "$(ls -A $DATADIR)" ]; then
  	echo "Data directory is empty..."
	read -r -p "Copy files from the directory provided? (y/n/Quit): " choi
  	
	case $choi in
		"y")
			echo "Copying files..."
			cd "$CIPHER_ROUNDDATA/" 
			cp * "../../../$DATADIR"
			cd ../../..
			echo "After copy..."
			cd "$DATADIR"
			ls
			cd .. 
			;;
		"n")
			echo "Not copying the files..quiting.."
			exit
			;;
		"Quit")
			exit
			;;
		*) echo "Invalid option...quiting.."
		   exit
		   ;;
	esac
  	
	exit
else
	echo "Input directory contains the following:"
	ls "$DATADIR"
	read -r -p "Delete All and copy from the directory provided? (y/n/Quit): " choi
  	
	case $choi in
		"y")
		    echo "Deleting old files..."
		    cd "$DATADIR"
		    rm *
		    cd ..
			echo "Copying files..."
			cd "$CIPHER_ROUNDDATA/" 
			cp * "../../../$DATADIR"
			cd ../../..
			echo "After copy..."
			cd "$DATADIR"
			ls 
			cd ..
			;;
		"n")
			echo "Not copying the files..quiting.."
			exit
			;;
		"Quit")
			exit
			;;
		*) echo "Invalid option...quiting.."
		   exit
		   ;;
	esac	
	
fi	

echo ""
echo "So you are analyzing:" 
echo "$CIPHER_ROUNDDATA"
echo ""
#----------------------------------------------------------------------------------------------------------------#

                                       #------------------------------------#
 									   # Create the environment for DFATool #
									   #------------------------------------#

INPUTDIR="./arff"
OUTPUTDIR="./results"
CIPHERDESCDIR="./Cipherfiles"

FILEEXT_ARFF=".arff"
FILEEXT_ITEMSET=".itemset"
FILEEXT_CIPHER=".cipher"

CIPHER_FILENAME=""
INFO_STR=0

########## New Inclusion 9_6_2021
CDG_GRAPH_FOLDERNAME=""
#################################

USE_OLDDATA_FLAG=0
PRINT_CDG=0
FULL_KEY_STATE_IN_EACH_ROUND=""

export INPUTDIR
export OUTPUTDIR
export CIPHERDESCDIR
export FILEEXT_ARFF
export FILEEXT_ITEMSET
export FILEEXT_CIPHER
export CIPHER_FILENAME
export INFO_STR
export USE_OLDDATA_FLAG
export PRINT_CDG
export FULL_KEY_STATE_IN_EACH_ROUND

if [ ! -d $INPUTDIR ];then
	echo "No input directory ($INPUTDIR) exists. Creating... "
	mkdir $INPUTDIR
	echo "Input directory \"$INPUTDIR\" created..."
fi
echo " "
echo " "

if [ ! -d $OUTPUTDIR ];then
	echo "No output directory ($OUTPUTDIR) exists. Creating... "
	mkdir $OUTPUTDIR
	echo "Output directory \"$OUTPUTDIR\" created..."
fi
echo " "
echo " "

if [ ! -d $CIPHERDESCDIR ];then
	echo "No directory for keeping cipher descriptions ($CIPHERDESCDIR) exists. Creating... "
	mkdir $CIPHERDESCDIR
	echo "Cipherfiles directory \"$CIPHERDESCDIR\" created..."
fi
echo " "
echo " "

#mv *.arff $INPUTDIR
#### New Inclusion (probably temporary) 04_06_2021....
#if [ "$(ls -A $INPUTDIR)" ]; then
#	VAR="${INPUTDIR:2}"
#	rm $VAR/*.arff
#fi 
#rm attack_dist/dist*
#exit
######################

# Look for empty dir.... 
if [ ! "$(ls -A $INPUTDIR)" ]; then
    echo "REMEMBER: You need to put at least one input file ($FILEEXT_ARFF) inside $INPUTDIR directory ..."
    echo "Currently they are not automatically exported from FaultSim-v1.1"
    echo "Please export them manually... "
    echo "Until then, I'll wait...Please press any key when you are done."
	read -n 1 -s
else
	echo " "
    echo "Found input files...All Ok till now.."
fi

echo " "
echo " "

# Check once again if there are input files...
if [ ! "$(ls -A $INPUTDIR)" ]; then
	echo "I found no input $FILEEXT_ARFF file. Aborting..."
	exit
else
	if [ "$USE_OLDDATA_FLAG" == 1 ]; then
		echo ""
		echo "[WARNING]: USE_OLDDATA_FLAG set to 1. Sanity checking of input .arff filenames will not"
		echo "take place. This is a temporary add-on to use old trace files we have collected..."
		echo "no output file will be generated in this mode... However, you can always use the .log files"
		echo ""
	else
		INFO_STR=$(checkarfffilenames)
		if [ ! -z "$INFO_STR" ]; then
			echo " "
			echo "All Ok till now..Starting DFATool..."
		else
			echo "Your $FILEEXT_ARFF files contain traces from multiple ciphers or traces from different fault campaigns...Aborting...."
			exit
		fi
	fi		
fi
echo " "
echo " "

# Look for empty dir.... 
if [ ! "$(ls -A $CIPHERDESCDIR)" ]; then
    echo "REMEMBER: You need to put at least one input file ($FILEEXT_CIPHER) inside $CIPHERDESCDIR directory ..."
    echo "Currently they are not automatically exported and you have to write them down."
    echo "Please export them manually... "
    echo "Until then, I'll wait...Please press any key when you are done."
	read -n 1 -s
else
	echo " "
    echo "Found input files...All Ok till now.."
fi

echo " "
echo " "

# Check once again if there are input files...
# You can select only one .cipher file at a time. 
# Please make sure that is consistant with your simulation files.
if [ ! "$(ls -A $CIPHERDESCDIR)" ]; then
	echo "I found no input $FILEEXT_CIPHER file. Aborting..."
	exit
else			# if there are more than one input files
    if [  "$(ls -lR ./$CIPHERDESCDIR/*$FILEEXT_CIPHER | wc -l) >= 1" ]; then
        echo "I found $(ls -lR ./$CIPHERDESCDIR/*$FILEEXT_CIPHER | wc -l) input $FILEEXT_CIPHER files. "
        echo "You have to select one of them describing the cipher you are analyzing "
        echo "and consistant with your trace file..."
        echo "Here are the name of the files..."
        echo "Please choose one of them..."
        CIPHER_FILENAME=$(selectmenu $CIPHERDESCDIR $FILEEXT_CIPHER)
        echo "File $CIPHER_FILENAME selected"
        if [[ $CIPHER_FILENAME = "Stop the script" ]]; then
            echo "You chose to stop. Aborting..."
            exit
        fi
	fi
	echo " "
    echo "All Ok till now..Starting DFATool..."
fi

#####TODO: Put a check to see if the .cipher and .arff files are consistant to each other ####

##############################################################################################

########## New Inclusion 9_6_2021
if [ $PRINT_CDG -eq 1 ];then 
 echo "here"
 V2=$CIPHER_FILENAME
 IFS='/'
 set -- $V2
 V3="${3}"
 IFS='.'
 set -- $V3
 CDG_GRAPH_FOLDERNAME="cdg_${1}"
 echo $CDG_GRAPH_FOLDERNAME
 if [ ! -d $CDG_GRAPH_FOLDERNAME ];then
	echo "No input directory ($CDG_GRAPH_FOLDERNAME) exists. Creating... "
	mkdir $CDG_GRAPH_FOLDERNAME
	echo "Input directory \"$CDG_GRAPH_FOLDERNAME\" created..."
 fi
 #mkdir $CDG_GRAPH_FOLDERNAME 
fi
#exit
#################################



								#---------------------------#
								#    DFATool begins here    #
								#---------------------------#
echo "							#############################"
echo "							#      DFATool-v1.1         #"
echo "							#                           #"
echo "							# Author: Sayandeep Saha    #"
echo "							#                           #"
echo "							# Last Modified: 9/12/2017  #"
echo "							#############################"
#---------------------------------------------------------------------------------------------------#
#							Step 1: Distinguisher Identification									#
#---------------------------------------------------------------------------------------------------#
# Step 1.1: Generate itemsets from .arffs (if any) and dump them in an intermediate representation  #
# More precisely, we identify the variable sets and their corresponding itemsets and dump them	  	#
# to a file with .intermediate extension in an easily parsable format. Note that in the present	  	#
# version of our tool, we only require the variable sets and number of itemsets associated with   	#
# them. So, the original itemsets, althogh, printed in the file are kept  "#"-commented. This	  	#
# makes the file parser very simple. 															  	#	 	 
#																								  	#
# Note: This could be done in one shot where the .arffs will be analysed and distinguishers will  	#
# be identified. Unfortunately, weka is a java tool and currently there exists no reliable python 	#
# counterpart. The entropy computations in our tool involve multi-precision floating point		  	# 
# computatation, which is slightly tricky to perform in java. More specifically, no library is 	  	#	 
# available for computing multi-precision logarithm (one option is to implement Newton's 		  	#
# algorithm, but it might not be that optimized). That is why we decided to do bare minimum		  	# 
# computation in java and do the rest in python. This involves generating some intermediate		  	#
# files, though, but overall computational burden is negligible (just some extra file reads and   	#
# writes). 																						 	#
#---------------------------------------------------------------------------------------------------#

echo " "
echo "Step 1: Distinguisher Identifier Starts..."
echo " "

# Read the .arff files, run the APriori algorithm and dump the itemset results in an intermediate representation
#javac -cp $WEKA_HOME/weka.jar:. AprioriWrapper.java -Xlint:unchecked
#java -Xmx2g -cp $WEKA_HOME/weka.jar:. AprioriWrapper
# Remove java class files generated during execution
#rm *.class

########################################################################
# New Inclusion!!!! Fpgrowth Itemset miner... 04_06_2021
# Beta Version: Tested for AES; Partially tested for CLEFIA(needs few
# more test cases)
########################################################################
#n=1
#while read line; do
# reading each line
#echo "Line No. $n : $line"
#if [[ $line == "CIPHERNAME GIFT" ]]; then
#	break
#	echo "GIFT"
#else
	#python3 find_itemsets.py
#	echo "AES"
#fi	
#n=$((n+1))
#done < $CIPHER_FILENAME
if [[ $CIPHER_FILENAME =~ .*GIFT.* ]]; then    # A temporary mechanism, should actually include all permutation-based ciphers
	echo ""
	rm results/*.itemset
	FULL_KEY_STATE_IN_EACH_ROUND=0
else
	FULL_KEY_STATE_IN_EACH_ROUND=1
	python3 find_itemsets.py
fi	
#python3 find_itemsets.py
########################################################################

#--------------------------------------------------------------------------------------------------#
# 		Step 1.2: Now read the .arff and .intermediate files and identify the distinguishers	   #
#--------------------------------------------------------------------------------------------------# 

#python3 Distinguisher_Identifier.py	

#python3 cdgMain.py ./Cipherfiles/PRESENT.cipher
#python3 cdgMain.py ./Cipherfiles/AES.cipher

python3 DFATool.py
#./DFATool.pyc

exit
