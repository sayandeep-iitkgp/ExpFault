from __future__ import division, print_function
from __future__ import absolute_import

import os
import sys
import shutil
import time
import re
import collections
import warnings
import networkx
import networkx as nx
import pygraphviz as pgv

from queue import *
from enum import Enum
from networkx import *
from networkx.drawing.nx_agraph import graphviz_layout
import matplotlib.pyplot as plt



class Suboperation(object):
	
	def __init__(self):
		self._opname = ""
		self._optype = ""
		self._opip_size = 0
		self._opop_size = 0
		self._ifkeyip = False
		self._ifnonlinear = False
		self._keyip_size = 0
		self._opdict = {}
				
class Cipher(object):
	
	"""Constructs the structure compatible for creating a Cipher Dependency Graph (CDG) by reading a given cipher description.
	   The cipher description is to be given via an input file. User need to create
	   such an input file for each cipher he/she wants to analyze.
	"""
	# Not all possible errors are handled in this initial implementation.
	# Sequence of the commands are not checked and it is assumed that the user enters them correctly in the input file or 
	# they get caught by some internal error checking conditions. 	

	def __init__(self):
		self._ciphername = ""
		self._ciphertype = ""
		self._nr = 0
		self._bitwidth = 0
		self._rkeywidth = 0
		self._nsub = 0
		self._suboplist = []
		self._subopdescr = []
		self._roundlist = {}
			
	def __getattr__(self,filename):
		
		# Populate the cipher structure by reading the .cipher file
		ciphername_cntr = 0
		ciphertype_cntr = 0
		nr_cntr = 0
		bitwidth_cntr = 0
		rkeywidth_cntr = 0
		nsub_cntr = 0
		subop_cntr = 0
		beginblock_cntr = 0
		endblock_cntr = 0
		optype_cntr = 0
		opinput_cntr = 0
		opoutput_cntr = 0
		keyinput_cntr = 0
		round_cntr = 0
		
		ciphername_flag = False
		ciphertype_flag = False
		nr_flag = False
		nsub_flag = False
		bitwidth_flag = False
		rkeywidth_flag = False
		beginblock_flag = False
		endblock_flag = False
		optype_flag = False
		opinput_flag = False
		opoutput_flag = False
		keyinput_flag = False
		
		
		beginblock_token = ""
		endblock_token = ""		
		
		# List of Keywords
		CIPHERNAME = re.compile('CIPHERNAME')
		CIPHERTYPE = re.compile('CIPHERTYPE')
		NR = re.compile('NR')
		BITWIDTH = re.compile('BITWIDTH')
		RKEYWIDTH = re.compile('RKEYWIDTH')
		NSUB = re.compile('NSUB')
		SUBOP = re.compile('SUBOP')
		BEGINBLOCK = re.compile('BEGINBLOCK')
		ENDBLOCK = re.compile('ENDBLOCK')
		OPTYPE = re.compile('OPTYPE')
		OPINPUT = re.compile('OPINPUT')
		OPOUTPUT = re.compile('OPOUTPUT')
		KEYINPUT = re.compile('KEYINPUT')
		ROUND = re.compile('ROUND')
	
		
		# Get the .cipher file inside the buffer and break it by newlines
		linelist =  open(filename, 'rU').read().splitlines() 
		
		# Remove empty lines and comment lines from the list
		linelist = list(filter(None, linelist))
		linelist = [x for x in linelist if not x.startswith('#')]
		
		
		for line in linelist:
			
			# Handling basic cipher properties
			if (CIPHERNAME.match(line) and not ciphername_flag):
				ciphername_flag = True
				ciphername_cntr = ciphername_cntr + 1
				tokens = line.rsplit()
				self._ciphername = str(tokens[1]) 
			elif (CIPHERNAME.match(line) and ciphername_flag):
				raise ValueError("Multiple instances of ciphername found. Considering the first one..")
					
			if (CIPHERTYPE.match(line) and not ciphertype_flag):
				ciphertype_flag = True
				ciphertype_cntr = ciphertype_cntr + 1
				tokens = line.rsplit()
				self._ciphertype = str(tokens[1]) 
			elif (CIPHERTYPE.match(line) and ciphertype_flag):
				raise ValueError("Multiple instances of ciphertype found. Considering the first one..")
						
			if (NR.match(line) and not nr_flag):
				nr_flag = True
				nr_cntr = nr_cntr + 1
				tokens = line.rsplit()
				self._nr = int(tokens[1]) 
			elif (NR.match(line) and nr_flag):
				raise ValueError("Multiple instances of nr found. Considering the first one..")

			if (NSUB.match(line) and not nsub_flag):
				nsub_flag = True
				nsub_cntr = nsub_cntr + 1
				tokens = line.rsplit()
				self._nsub = int(tokens[1]) 
			elif (NSUB.match(line) and nsub_flag):
				raise ValueError("Multiple instances of nsub found. Considering the first one..")

			if (BITWIDTH.match(line) and not bitwidth_flag):
				bitwidth_flag = True
				bitwidth_cntr = bitwidth_cntr + 1
				tokens = line.rsplit()
				self._bitwidth = int(tokens[1]) 
			elif (BITWIDTH.match(line) and bitwidth_flag):
				raise ValueError("Multiple instances of bitwidth found. Considering the first one..")

			if (RKEYWIDTH.match(line) and not rkeywidth_flag):
				rkeywidth_flag = True
				rkeywidth_cntr = rkeywidth_cntr + 1
				tokens = line.rsplit()
				self._rkeywidth = int(tokens[1]) 
			elif (RKEYWIDTH.match(line) and rkeywidth_flag):
				raise ValueError("Multiple instances of rkeywidth found. Considering the first one..")
												
			
			# Handling the Sub-operation declarations
			if (SUBOP.match(line) and subop_cntr <= self._nsub):
				subop_cntr = subop_cntr + 1
				tokens = line.rsplit()
				self._suboplist.append(str(tokens[1])) 
			if (SUBOP.match(line) and subop_cntr > self._nsub):
				raise ValueError("Number of subops specified is less than the number of subops declared..")			

			# Handling the BEGINBLOCK ... ENDBLOCK Blocks---------------
			
			# Enter a block with BEGINBLOCK
			# Not all possible errors are handled in this initial implementation.
			# Sequence of the commands are not checked and it is assumed that the user enters them correctly in the input file or 
			# they get caught by some internal error checking conditions. 
			
			if (BEGINBLOCK.match(line) and not beginblock_flag):		# Enter only if no other BEGINBLOCK is under process
				tokens = line.rsplit()
				if (str(tokens[1]) in self._suboplist):
					beginblock_flag = True		# Flag to check block syntax
					endblock_flag = True		# Flag to check block syntax
					beginblock_token = tokens[1] # SUBOP name from the block 
					endblock_token = tokens[1]	 # SUBOP name from the block (this is to be checked when the next ENDBLOCK will be encountered) 	
					self._subopdescr.append(Suboperation())	# Create a suboperation object corresponding to the block encountered
					optype_flag = False			# Flag for a block attribute
					opinput_flag = False		# Flag for a block attribute
					opoutput_flag = False		# Flag for a block attribute
					keyinput_flag = False		# Flag for a block attribute			
					beginblock_cntr	 = beginblock_cntr + 1	# Counts how many blocks has been encountered so far
					self._subopdescr[beginblock_cntr - 1]._opname = str(tokens[1]) # Set the name of the suboperation 
					continue													# go to next line
				else:
					raise ValueError("Unknown Sub-op name in BEGINBLOCK..")		# If SUBOP name in beginblock is unknown 
			if (beginblock_flag):										# You are operating inside the BEGINBLOCK				   
				if (ENDBLOCK.match(line) and endblock_flag):					# ENDBLOCK encountered
					tokens = line.rsplit()
					if( (str(tokens[1]) in self._suboplist) and (endblock_token == tokens[1]) ): # Check if the SUBOP matches with the last encountered BEGINBLOCK
						endblock_flag = False									# Ready to process another block
						beginblock_flag = False									# Ready to process another block
						endblock_cntr = endblock_cntr + 1						# Count the endblock (currently not in use)
						if ( (not optype_flag) or (not opinput_flag) or (not opoutput_flag) ):  # Flags for essential block attributes
							raise AttributeError("Some block attributes are not specified..")												
						continue
					else:
						raise ValueError("Unknown Sub-op name in ENDBLOCK..")	
				
				# Process the basic attrtibutes of the blocks here...		
				
				if (OPTYPE.match(line) and not optype_flag):
					optype_flag = True
					optype_cntr = optype_cntr + 1 
					tokens = line.rsplit()
					self._subopdescr[beginblock_cntr - 1]._optype = str(tokens[1])
					if(self._subopdescr[beginblock_cntr - 1]._optype == "NONLINEAR"):
						self._subopdescr[beginblock_cntr - 1]._ifnonlinear = True
					else:
						self._subopdescr[beginblock_cntr - 1]._ifnonlinear = False	
				elif (OPTYPE.match(line) and optype_flag):
					raise ValueError("Multiple instances of optype found within same block. Considering the first one..")	
								
				if (OPINPUT.match(line) and not opinput_flag):
					opinput_flag = True
					opinput_cntr = opinput_cntr + 1 
					tokens = line.rsplit()
					self._subopdescr[beginblock_cntr - 1]._opip_size = int(tokens[1])
				elif (OPINPUT.match(line) and opinput_flag):
					raise ValueError("Multiple instances of opinput found within same block. Considering the first one..")				
				
				if (OPOUTPUT.match(line) and not opoutput_flag):
					opoutput_flag = True
					opoutput_cntr = opoutput_cntr + 1 
					tokens = line.rsplit()
					self._subopdescr[beginblock_cntr - 1]._opop_size = int(tokens[1])
				elif (OPOUTPUT.match(line) and opoutput_flag):
					raise ValueError("Multiple instances of opoutput found within same block. Considering the first one..")		
				
				if (KEYINPUT.match(line) and not keyinput_flag):
					keyinput_flag = True
					keyinput_cntr = keyinput_cntr + 1 
					tokens = line.rsplit()
					self._subopdescr[beginblock_cntr - 1]._ifkeyip = True
					self._subopdescr[beginblock_cntr - 1]._keyip_size = int(tokens[1])
				elif (KEYINPUT.match(line) and keyinput_flag):
					raise ValueError("Multiple instances of keyinput found within same block. Considering the first one..")						
				
				# Process the block functions here
				if (str(line).startswith("%")):
					delimiters = ",", " ", "+"
					regexPattern = '|'.join(map(re.escape, delimiters))
					llist = re.split(regexPattern, line)
					llist = list(filter(None, llist))
					llist = [x for x in llist if not x.startswith('%')]
					templ = [int(llist[x]) for x in range(len(llist)) if x > 1]
					if (self._subopdescr[beginblock_cntr - 1]._ifkeyip):
						templ = [[int(llist[x])] for x in range(len(llist)) if x > 1]
					else:
						templ = [templ]	
					self._subopdescr[beginblock_cntr - 1]._opdict[int(llist[0])] = templ
																				
				continue				
			if (ENDBLOCK.match(line) and not endblock_flag):
				raise SyntaxError("No matching BEGINBLOCK found..")
			
					
			# Handling the lines describing the rounds
			if (ROUND.match(line) and round_cntr <= self._nr):
				round_cntr = round_cntr + 1
				tokens = line.rsplit()
				sops = [tokens[x+2] for x in range(len(tokens) - 2)] 
				if (len(sops) > self._nsub):
					raise ValueError("Number of suboperations in a round doesnot comply with total number of subops allowed (NSUB)")
				for x in sops:
					if x not in self._suboplist:
						raise ValueError("Undefined suboperation in round description..")							
				self._roundlist[int(tokens[1])] = sops
			if (ROUND.match(line) and round_cntr > self._nr):
				raise ValueError("Number of rounds specified is less than the number of rounds declared..")						
		
		if (not ciphername_flag):
			raise AttributeError("No Ciphername specified..")	
		if (not ciphertype_flag):
			raise AttributeError("No Ciphertype specified..")	
		if (not nr_flag):
			raise AttributeError("No Number of rounds specified..")		
		if (not nsub_flag):
			raise AttributeError("No Number of sub-operations specified..")	
		if (not bitwidth_flag):
			raise AttributeError("No bitwidth specified..")		
		if (not rkeywidth_flag):
			raise AttributeError("No roundkeywidth specified..")						
		if (subop_cntr < self._nsub):
			raise AttributeError("Number of subops specified is more than the number of subops declared..")		
		if (round_cntr < self._nr):
			raise AttributeError("Number of rounds specified is more than the number of rounds declared..")				
		if (beginblock_flag):
			raise SyntaxError("At least one BEGINBLOCK found no ENDBLOCK")				
			
	def	_repr_(self):
		# Print the complete cipher description
		print(self._ciphername)
		print(self._ciphertype)
		print(self._nr)
		print(self._nsub)
		print(self._bitwidth)
		print(self._rkeywidth)
		print(self._suboplist)
		print("")
		for i in range(len(self._subopdescr)):
			print("")
			print(self._subopdescr[i]._opname)
			print(self._subopdescr[i]._optype)
			print(self._subopdescr[i]._opip_size)
			print(self._subopdescr[i]._opop_size)
			print(self._subopdescr[i]._ifkeyip)
			print(self._subopdescr[i]._keyip_size)
			print(self._subopdescr[i]._opdict)
		
		print("")
				
	def __cmp__(self, other):
		print("To be written later...")
		
class cdgNode (object):
	
	def __init__(self, nodeid, levelid, iskeynode = False, isciphertextnode = False, isplaintextnode = False):
		self._id = nodeid					# id of the node
		self._predlist = []					# For future use
		self._succlist = []					# For future use
		self._whichlevel = levelid			# level id of the node
		self._iskeynode = iskeynode			# if it is a key node
		self._incidentkeynodes = []			# key node incident on this node (if any). To be populated during cdg construction
		self._isciphertextnode = isciphertextnode # if it is a ciphertext node
		self._isplaintextnode = isplaintextnode		# if it is a plaintext node 

class cdgLevel (object):
	
	def __init__(self, levelid, subopind, iskeyop, isnonlinear, nstate_bits, nrkey_bits, ind_first_node):
		self._levelid = levelid
		self._subopid = subopind
		self._iskeylevel = iskeyop
		self._isnonlinear = isnonlinear
		self._nstatenode = nstate_bits
		self._nrkeynode = nrkey_bits
		self._nnode_level = self._nstatenode + self._nrkeynode
		self._nodes = {}
		self._keynodes = {}
		# Generate the nodes ----
		# First generate the state nodes
		
		# identify the plantext and ciphertext levels
		isplaintextnode = False
		isciphertextnode = False
		if (self._levelid == 0):
			isplaintextnode = True
		if (self._levelid > 0 and self._subopid == -1):	
			isciphertextnode = True
		for n in range(self._nstatenode):
			iskeynode=False
			self._nodes[n] = cdgNode( (ind_first_node + n), self._levelid, iskeynode, isciphertextnode, isplaintextnode )
		
		# Next, generate the key nodes (if any)
		if (self._iskeylevel): 
			for n in range(self._nrkeynode):
				iskeynode=True
				self._keynodes[n] = cdgNode( (ind_first_node + self._nstatenode + n), self._levelid, iskeynode, isciphertextnode, isplaintextnode )
			
class word_Variable(object):
	
	def __init__(self, bitvarlist, wordvarindx):
		self._wordvarindx = wordvarindx
		self._bitvarlist = bitvarlist

class variable_Set(object):
	def __init__(self, Varset, set_indx):
		self._set_indx = set_indx
		self._Varset = Varset
	
class keySet(object):
	def __init__(self, keylist):
		self._keylist = keylist	
		
	def hasoverlap(self, keyset1):
		return bool(set(self._keylist) & set(keyset1._keylist))
				 	
class MKS(object):
	def __init__(self, keylist):
		mks = set(keylist[0]._keylist)
		for key in keylist:
			mks |= set(key._keylist)
		self._mks = list(mks)	
							
class VG(object):
	def __init__(self, varlist):
		self._vg = varlist

class CDG(Cipher):
	
	def __init__(self, cipher, cdgtype = None):
		
		self.CONST = 99999
		self._cname = cipher._ciphername
		self._levelsubop_list = [] 							# A list containing the subop-ids corresponding to each level	
		self._nlevel = 0
		
		# Count the number of levels and populate the levelsubop_list with integer subop indices to which the corresponding level is an input
		for x in range(cipher._nr):
			r = cipher._roundlist[x+1]
			for y in r:
				self._levelsubop_list.append(cipher._suboplist.index(y)+1)
				self._nlevel = self._nlevel + 1			# Each level, except the last one is 
														# considered as an input to some subop.
														# The last level is the ciphertext.		
		self._levelsubop_list.append(-1) 				# level index of the ciphertext level is set as -1
		self._nlevel = self._nlevel + 1
																																			
		self._levellist = {}
		self._nnode = (self._nlevel * cipher._bitwidth) + (cipher._nr * cipher._rkeywidth) # Total number of nodes in the graph
		
		# Additionally, we create a dictionary of {<subopind>:<subopobj>}. (this is added later and some codes can be optimized based on this) 
		self._subbopdict = {}
		for s in cipher._subopdescr:
			self._subbopdict[cipher._suboplist.index(s._opname) + 1] = s
		
						
		# Create the levels	
		ind_first_node = 0
		for l in range(self._nlevel):
			nstate_bits = cipher._bitwidth
			nrkey_bits = 0				
			iskeyop = False
			isnonlinear = False
			# indicate whether a level involves key addition
			if (self._levelsubop_list[l] != -1):
				level_name_temp = cipher._suboplist[self._levelsubop_list[l] - 1]
				for s in cipher._subopdescr:
					if ( (s._opname == level_name_temp) and (s._ifkeyip)):
						iskeyop = True
						nrkey_bits = cipher._rkeywidth
					if ( (s._opname == level_name_temp) and (s._ifnonlinear)):
						isnonlinear = True					 
			self._levellist[l] = cdgLevel(l, self._levelsubop_list[l], iskeyop, isnonlinear, nstate_bits, nrkey_bits, ind_first_node)
			ind_first_node = ind_first_node + self._levellist[l]._nnode_level
			
		if (cdgtype is None):
			self._cdg = nx.Graph()	
		elif (cdgtype == "dag"):			
			self._cdg = nx.DiGraph()
		else:
			raise ValueError ("Unsupported cdgtype specified..")	
	
	def __repr__(self):
		print("Under construction")	
		print(self._nlevel)
		print(self._nnode)
		for l in range(self._nlevel):
			print(self._levellist[l]._levelid)
			print(self._levellist[l]._subopid)
			print(self._levellist[l]._iskeylevel)
			print(self._levellist[l]._nnode_level)
			for n in range(self._levellist[l]._nstatenode):
				print(self._levellist[l]._nodes[n]._id)
			if (self._levellist[l]._iskeylevel):
				for n in range(self._levellist[l]._nrkeynode):
					print(self._levellist[l]._keynodes[n]._id)					
			print("")
			
	def createcdg (self, fromlevel = None, tolevel = None):
		#print("Creating the Cipher Dependency Graph (CDG)...")
		#print("")
		# Create links between the nodes from two consecutive levels

		if (fromlevel == None):
			startLevel = 0
		else:
			startLevel = fromlevel
		
		# Add the nodes from the first level
		for n in range(self._levellist[startLevel]._nstatenode):
			self._cdg.add_node(self._levellist[startLevel]._nodes[n])
		if (self._levellist[startLevel]._iskeylevel):
			for n in range(self._levellist[startLevel]._nrkeynode):
				self._cdg.add_node(self._levellist[startLevel]._keynodes[n])
		
		# Now add nodes from each level at a time and create the links with previous level
		
		if (tolevel == None):
			endLevel = self._nlevel
		else:
			endLevel = tolevel
		for l in range( (startLevel+1) ,endLevel):
		#for l in range(1,6):	
			#print(l)
			currlevel = self._levellist[l]
			prevlevel = self._levellist[l-1]
			for n in range(currlevel._nstatenode):
				self._cdg.add_node(currlevel._nodes[n])
			if (currlevel._iskeylevel):
				for n in range(currlevel._nrkeynode):
					self._cdg.add_node(currlevel._keynodes[n])
					
			# Create the links		
			sop = self._subbopdict[prevlevel._subopid]
			haskey = sop._ifkeyip
			opdict = sop._opdict
			# keys of the opdict will be the nodes of the currlevel
			for k in opdict:
				# store the keynode inside the node it is incident to for O(1) access
				if (haskey):
					currlevel._nodes[k]._incidentkeynodes.extend([ prevlevel._keynodes[i] for i in opdict[k][1] if opdict[k][1][0] != self.CONST])
				outnode = currlevel._nodes[k]
				inlist = opdict[k]
				if (haskey):
					inlist_s = inlist[0]
					inlist_k = inlist[1]
					for i in inlist_s:
						self._cdg.add_edge(prevlevel._nodes[i], outnode )
					for i in inlist_k:
						if (i != self.CONST):
							self._cdg.add_edge(prevlevel._keynodes[i], outnode )	
				else:
					inlist_s = inlist[0]
					for i in inlist_s:
						self._cdg.add_edge(prevlevel._nodes[i], outnode)						

	def viewcdg(self, fromlevel = None, tolevel = None):
		#print("View the CDG graphically (optional)")
		#print("")

		#gr = nx.draw_networkx(self._cdg, labels={})
		#plt.show()
		gr = self._cdg
		nodelist = gr.nodes
		nodelist = list(nodelist)
		mapping = {}
		for j in range(len(nodelist)):
			mapping[nodelist[j]] = nodelist[j]._id
		gr1 = nx.relabel_nodes(gr,mapping)
		
		G = networkx.drawing.nx_agraph.to_agraph(gr1)
		G.layout(prog='dot')
		#G.draw("/home/sayandeep/Desktop/Tool/Cipher_dependency_graph_gen/cdg_file.png")
		#fname = "./" + "cdg_file_" + str(self._cname) + "_" + str(fromlevel) + ".png"
		#fname_1 = "./" + "cdg_file_" + str(self._cname) + "_" + str(fromlevel) + ".dot"
		tmpvr = "cdg_" + self._cname + "/"
		fname = "./" + tmpvr + "cdg_file_" + str(self._cname) + "_" + str(fromlevel) + ".png"
		fname_1 = "./" + tmpvr + "cdg_file_" + str(self._cname) + "_" + str(fromlevel) + ".dot"		
		G.draw(fname)
		G.write(fname_1)
				
	def bfs_forest(self, nodeset_dist):
		# Get the nodes from which we have to do BFS
		#print("Do a series of BFS traversals")
		#print("")
		forest = {}
		for nd in nodeset_dist:
			forest[nd] = bfs_tree(self._cdg, nodeset_dist[nd])
			
		return forest
	
	def get_bitwise_keysets(self, nodeset_dist):
		#print("Get the keysets corresponding to each distinguisher bit")
		#print("")

		# First, we take the distinguisher bits as input (nodeset_dist)
		
		# Get the bfs forest rooted at each bit-node of the distinguisher
		forest = self.bfs_forest(nodeset_dist)
		
		# Now get the associated key-bit nodes with each distinguisher bit node
		bit_key_dict = {}
		for t in forest:
			tr = forest[t]		
			treenodelist = tr.nodes
			treenodelist = list(treenodelist)
			
			# Get the root node of a tree
			root = None	
			topo_srt_nodelist = nx.topological_sort(tr)
			topo_srt_nodelist = list(topo_srt_nodelist)
			root = topo_srt_nodelist[0]
			
			# Get the key nodes linked with the corresponding bfs tree
			tot_key_nodes_cnt = 0
			tree_keynodelist = []
			dl = nodeset_dist[0]._whichlevel
			for node in treenodelist:
				# Check if associated key nodes are actually required to be considered. The logic is 
				# to check the level of the key addition operations. If there exists some S-Box layer
				# between the distinguisher layer and the key addition layer, only then the key bits 
				# are required to be considered. Otherwise, they will get cancelled out during the
				# differential construction. So, need not to be considered.
				if (len(node._incidentkeynodes) != 0):  
					l = node._whichlevel
					checklist = [t for t in range(dl,l)]
					nonlinear_flag = False
					if (nonlinear_flag == False):
						for t in checklist:
							if(self._levellist[t]._isnonlinear):
								nonlinear_flag = True
					if (nonlinear_flag):		
						tot_key_nodes_cnt = tot_key_nodes_cnt + len(node._incidentkeynodes)
						tree_keynodelist.extend(node._incidentkeynodes)				
				#tot_key_nodes_cnt = tot_key_nodes_cnt + len(node._incidentkeynodes)
				#tree_keynodelist.extend(node._incidentkeynodes)
			
			# Create a dictionary which contains the list of key-bit nodes corresponding to each distinguisher bit-node
			bit_key_dict[root] = tree_keynodelist
		
		# Print the bfs trees to .png files (debugging code)
		#self.view_bfstrees(forest)
		
		return bit_key_dict			

	def view_bfstrees(self, forest):
		
		#print("View the bfs trees (optional: called from get_bitwise_keysets)")
		# View the trees one by one (debugging code)
		fname_str = '/home/sayandeep/Desktop/Tool/Cipher_dependency_graph_gen/BFS_trees/'
		for nd in forest:
			tr = forest[nd]		
			treenodelist = tr.nodes
			treenodelist = list(treenodelist)

			mapping = {}
			for j in range(len(treenodelist)):
				mapping[treenodelist[j]] = treenodelist[j]._id
			tr1 = nx.relabel_nodes(tr,mapping)			 	
			
			T = networkx.drawing.nx_agraph.to_agraph(tr1)			
			T.layout(prog='dot')
			
			fname = fname_str + 'cdg_tree_' + str(nd) + '.png'
			T.draw(fname)
			pause()
	
	def get_varwise_keysets(self, bit_key_dict, dist_wordsize, word_var_indx_at_dist_level):
		#print("Combine the keysets according to the variables considered in distinguisher identification ")
		#print("")
		
		word_key_dict = {}
		
		# First sort the bit_key_dict according to node._id's
		dist_bit_nodes_sorted = sorted(bit_key_dict.items(), key=lambda x: x[0]._id)
		dist_bit_nodes_sorted = collections.OrderedDict(dist_bit_nodes_sorted)
		
		# Now, select <dist_wordsize> consecutive nodes at a time and take a set-union of their keys
		for i in range(0, len(dist_bit_nodes_sorted.keys()), dist_wordsize):
			tmp_key_list = list(dist_bit_nodes_sorted.keys())[i:i+dist_wordsize]
			tmp_val_list = [dist_bit_nodes_sorted[x] for x in tmp_key_list]
			
			wordvarindx = word_var_indx_at_dist_level[int(i/dist_wordsize)]
			
			tmp_set = set(tmp_val_list[0])
			for j in tmp_val_list:
				tmp_set = tmp_set | set(j)
			
			tmp_val_union = list(tmp_set)	
			word_var = word_Variable(tmp_key_list,wordvarindx)
			word_key_dict[word_var] = tmp_val_union
			
		# sort the dictionary according to word variable indices
		word_key_dict_sorted = sorted(word_key_dict.items(), key=lambda x: x[0]._wordvarindx)
		word_key_dict = collections.OrderedDict(word_key_dict_sorted)			
			
		return word_key_dict
	
	def get_varsetwise_keysets(self, word_key_dict, Varset_list, Var_indx_list, Varset_no):
		#print("Get the keysets corresponding to each variable set (as they are present in the distinguisher)")	
		#print("")
		
		Varset_key_dict = {}
		
		for V in  Var_indx_list:
			set_indx = Var_indx_list.index(V)
			vs = []
			ks = set()
			for v in V:
				vs.append(list(word_key_dict.keys())[v])
				ks |= set(word_key_dict[list(word_key_dict.keys())[v]])	
			vs = variable_Set(vs, set_indx)
			Varset_key_dict[vs] = list(ks)
		
		# sort the dictionary according to word variable indices
		Varset_key_dict_sorted = sorted(Varset_key_dict.items(), key=lambda x: x[0]._set_indx)
		Varset_key_dict = collections.OrderedDict(Varset_key_dict_sorted)		
		
		return Varset_key_dict
	
	def get_MKS_VG(self, Var_or_varset_key_dict):
		#print("Combine the variables/variable sets according to Maximum independent key sets (MKS) ")		 	
		#print("")
		# The keylists corresponding to each variable/variable-set (in the input dictionary) 
		# must be converted to a keySet object. This is a syntactic decision to maintain clarity and
		# to access things easily. 
		
		Var_or_varset_key_dict_mod = {}
		for k,v in Var_or_varset_key_dict.items():
			Var_or_varset_key_dict_mod[k] = keySet(v)
				
		
		# keep it sorted
		#Var_or_varset_key_dict_mod_sorted = sorted(Var_or_varset_key_dict_mod.items(), key=lambda x: x[0]._wordvarindx)
		Var_or_varset_key_dict_mod_sorted = sorted(Var_or_varset_key_dict_mod.items(), key=lambda x: x[0]._wordvarindx if isinstance(x[0], word_Variable ) else x[0]._set_indx)
		Var_or_varset_key_dict_mod = collections.OrderedDict(Var_or_varset_key_dict_mod_sorted)	
		
		# invert the input dictionary
		inverted_dict = {}
		for k,v in Var_or_varset_key_dict_mod.items():
			inverted_dict[v] = k
		
		# Construct the MKS and VGs-------
		# Create an undirected graph with the key sets as nodes where there will be an edge between two key sets 
		# if and only if they have some common element
		MKS_VG_dict = {}
		Overlap_graph = self.create_overlap_graph(inverted_dict)
		
		# Now find the connected components in the overlap graph
		components = sorted(nx.connected_components(Overlap_graph), key = len, reverse=True)
		for comp in components:
			mks = []
			vg = []
			for nd in comp:
				mks.append(nd[0])
				vg.append(nd[1])
			MKS_VG_dict[MKS(mks)] = VG(vg)
				
		return MKS_VG_dict
	
	def create_overlap_graph(self, inverted_dict):
		
		# Create the graph between oberlapping keysets while keeping track of their associated 
		# variables or variable-sets
		
		Overlap_graph = nx.Graph()
		
		inverted_dict_keys = list(inverted_dict.keys())
		flag_matrix = [[False]*len(inverted_dict_keys) for _ in range(len(inverted_dict_keys))]	
		
		for keyset in inverted_dict_keys:
			Overlap_graph.add_node((keyset, inverted_dict[keyset]))
		
		for keyset in inverted_dict_keys:
			flag_matrix[inverted_dict_keys.index(keyset)][inverted_dict_keys.index(keyset)] = True
			for keyset1 in inverted_dict:
				if (inverted_dict_keys.index(keyset1) > inverted_dict_keys.index(keyset)):
					if (keyset.hasoverlap(keyset1)):
						Overlap_graph.add_edge( (keyset, inverted_dict[keyset]), (keyset1, inverted_dict[keyset1]) )

		# Print the overlap graph to file (debugging code)
		#Ogr = networkx.drawing.nx_agraph.to_agraph(Overlap_graph)			
		#Ogr.layout(prog='dot')
		#Ogr.draw("/home/sayandeep/Desktop/Tool/Cipher_dependency_graph_gen/overlap_graph_file.png")		
		return Overlap_graph

def pause():
	programPause = input("Press the <ENTER> key to continue...")
	
