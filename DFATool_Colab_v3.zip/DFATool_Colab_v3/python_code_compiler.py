import py_compile

py_compile.compile('Distinguisher_Identifier.py')
py_compile.compile('cdg.py')
py_compile.compile('DFATool.py')
