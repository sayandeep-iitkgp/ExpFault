from cdg import *
from Distinguisher_Identifier import *
from operator import itemgetter
import time

def create_dist_word_variables(distinguisher,cdg):
	r""" This function maps the word level symbolic variables of the distinguishers 
	to an equivalent numerical identifier. The identifiers are assigned based on
	the level number of the distinguisher. It also handles variable sets and
	other similar easy to handle structures are created."""
	
	# Distinguisher Variables (word level)
	# Distinguisher variables are actually integer identifiers which can be directly calculated given the 
	# distinguisher level number and dist_wordsize.
	dist_level = distinguisher._state_idx
	dist_wordsize = distinguisher._wordsize
	var_start_indx = 0
	for l in cdg._levellist:
		if (l < dist_level):
			var_start_indx = var_start_indx + int(cdg._levellist[l]._nnode_level/dist_wordsize)
	# index of word variables at the distinguisher level 
	word_var_indx_at_dist_level = [var_start_indx + i for i in range(int(cdg._levellist[dist_level]._nnode_level/dist_wordsize))]
	
	dist_var_dict = {}
	# create a map keyed with symbolic word variables from the distinguisher object for the variable identifiers
	for k in range(distinguisher._numAttributes):
		dist_var_dict[distinguisher._varlist[k]] = word_var_indx_at_dist_level[k]
	
	
	Varset_list = None			 # list of Varsets; each varset is described in terms of integer identifiers of variables.
	Varset_sym_to_id_dict = None # A dictionary to map symbolic varsets to varset described with integer identifiers. 
								 # the keys are tuples of symbolic varsets combined with an index of the varset. 
	Var_indx_list = None		 # stores indices of variables in each varset (just for efficient coding)
	Varset_no = None			 # Varset_1, Varset_2,..etc 

	if (distinguisher._exists_Varset):
		Varset_list = []		
		Varset_sym_to_id_dict = {}
		Var_indx_list = []		
		Varset_no = []			
		var_indx = 0
		cnt = 0 		
		Varset_list_symb = distinguisher._Varsetlist
		for varset in Varset_list_symb:
			vset_iden = []
			Varset_size = len(varset)
			for v in varset:
				vset_iden.append(dist_var_dict[v])
			Varset_list.append(vset_iden)
			Varset_list = sorted(Varset_list, key=itemgetter(0))
			Var_indx_list.append ([var_indx + x for x in range(Varset_size)])
			Varset_no.append(cnt)	
			Varset_sym_to_id_dict[tuple(varset)] = vset_iden
			cnt += 1
			var_indx += Varset_size
					
	return word_var_indx_at_dist_level, Varset_list, Varset_sym_to_id_dict, Var_indx_list, Varset_no, dist_var_dict

def get_distinguisher_eval_complexity(c, distinguisher_list, tolevel=None):
	
	result_list = []
	dist_var_dict_list = []
	Varset_sym_to_id_dict_list = []
	
	level_thr = 99999
	
	if tolevel is not None:
		level_thr = tolevel
		
	for distinguisher in distinguisher_list:
		if (distinguisher._state_idx < level_thr):
			cdg = CDG(c,cdgtype="dag")
			cdg.createcdg(fromlevel=distinguisher._state_idx, tolevel=tolevel)
			if ((print_cdg == 1) and (tolevel is None) ):		# Added tolevel; 09_06_2021
				cdg.viewcdg(fromlevel=distinguisher._state_idx, tolevel=tolevel)
			word_var_indx_at_dist_level, Varset_list, Varset_sym_to_id_dict, Var_indx_list, Varset_no, dist_var_dict = create_dist_word_variables(distinguisher,cdg)
			nodeset_dist = cdg._levellist[distinguisher._state_idx]._nodes
			no_of_nodes_dist = cdg._levellist[distinguisher._state_idx]._nstatenode
			
			# Get the key bits associated with each distinguisher bit
			bit_key_dict = cdg.get_bitwise_keysets(nodeset_dist)
			
			# Create key sets considering the <dist_wordsize>-bit distinguisher variables
			word_key_dict = cdg.get_varwise_keysets(bit_key_dict, distinguisher._wordsize, word_var_indx_at_dist_level)
		
			######################################################################
			# Experimental: In the case of incomplete diffusion, some of the word variables might be inactive.
			# They do not return any key. So, we just get rid of them while calculating the word_key_dict.
			
			st = True
			for d in range(distinguisher._numAttributes):
				st = st & distinguisher._Active[d]
			
			if (not st):					
				min_wordvarindx = math.inf
				for ac in word_key_dict.keys():
					if (ac._wordvarindx < min_wordvarindx):
						min_wordvarindx = ac._wordvarindx	
				
				word_key_dict_tmp = {}	
				for ac in word_key_dict.keys():
					d = (ac._wordvarindx - min_wordvarindx)
					if (distinguisher._Active[d]):
						word_key_dict_tmp[ac] = word_key_dict[ac]
				
				word_key_dict_tmp_sorted = sorted(word_key_dict_tmp.items(), key=lambda x: x[0]._wordvarindx)
				word_key_dict_tmp = collections.OrderedDict(word_key_dict_tmp_sorted)
				
				word_key_dict = word_key_dict_tmp
			############################################################################
			
			# Create key sets considering the distinguisher variable-sets (if they exists)
			# Note: Here we are assumeing that the distinguisher does not contain a mix of variable sets and individual variables
			# Although, this may happen in certain cases. For those cases we abstract the individual variables as single element variable
			# sets. This part is however not tested and may incur minor changes in the functions <cdg.get_varsetwise_keysets> and
			# <get_MKS_VG>. Soon, we shall check them once suitable examples are encountered.
			if (distinguisher._exists_Varset):
				Varset_key_dict = cdg.get_varsetwise_keysets(word_key_dict, Varset_list, Var_indx_list, Varset_no)	
				Var_or_varset_key_dict = Varset_key_dict
			else:	
				Var_or_varset_key_dict = word_key_dict
			
			# Create MKS and variable groups correspond to them	
			MKS_VG_dict = cdg.get_MKS_VG(Var_or_varset_key_dict)		
			
			result_list.append((distinguisher,cdg,MKS_VG_dict))
			dist_var_dict_list.append(dist_var_dict)
			Varset_sym_to_id_dict_list.append(Varset_sym_to_id_dict)
		
	return result_list, dist_var_dict_list, Varset_sym_to_id_dict_list	

def print_distinguisher_info(distinguisher_list, print_ranges=False, print_variable_sets=False, output_filename=None ):
	r""" Distinguisher information is printed in the following form 
	<Distinguisher_level_no><round_no><subop_no> <has_associations> <entropy>
	"""
	print("")
	print("")
	print("Printing the descriptions of the distinguishers found...")
	print("")
	print("")
	
	if (output_filename is not None):
		outfile = open(output_filename, 'a+')
		outfile.write("Distinguisher Level		Round_no		Subop_no		Has_associations	Entropy\n")
		outfile.close()
	
	print("Distinguisher Level		Round_no		Subop_no		Has_associations	Entropy")
	for distinguisher in distinguisher_list:
		if (output_filename is not None):
			outfile = open(output_filename, 'a+')
			outfile.write("		{}		{}		{}		{}		{}		{}\n".format(distinguisher._state_idx, distinguisher._state_diff_round_idx, distinguisher._state_diff_subop_idx, distinguisher._state_diff_subop_idx, distinguisher._exists_Varset, distinguisher._H_state)  )
			if (distinguisher._if_IDFA_distinguisher is True):
				outfile.write("This is a potential IDFA Distinguisher\n")
			outfile.close()
		print("		{}		{}		{}		{}		{}		{}".format(distinguisher._state_idx, distinguisher._state_diff_round_idx, distinguisher._state_diff_subop_idx, distinguisher._state_diff_subop_idx, distinguisher._exists_Varset, distinguisher._H_state)  )
		if (distinguisher._if_IDFA_distinguisher is True):
			print("This is a potential IDFA Distinguisher\n")		
		if(print_ranges):
			if (output_filename is not None):
				outfile = open(output_filename, 'a+')
			for k in distinguisher._var_ranges:
				print(k, distinguisher._var_ranges[k])
				if (output_filename is not None):
					outfile.write("{} ".format(k))
					outfile.write("[")
					for vrng in distinguisher._var_ranges[k]:
						outfile.write("%d, " %(vrng))
					outfile.write("]\n")	
			if (output_filename is not None):
				outfile.close()
				
		if (print_variable_sets):
			if (distinguisher._exists_Varset):
				print(distinguisher._Varsetlist)
				if (output_filename is not None):
					outfile = open(output_filename, 'a+')
					for vs in distinguisher._Varsetlist:
						outfile.write("[")
						for v in vs:
							outfile.write(v)
							outfile.write(", ")
						outfile.write("]: {} \n".format(distinguisher._Varset_symb_itemset_count_dist[tuple(vs)]))
				if (output_filename is not None):
					outfile.close()					
			else:
				if (output_filename is not None):
					outfile = open(output_filename, 'a+')
					outfile.write("No Variable sets exist..Cannot print anything...\n")
					outfile.close()
				print("No Variable sets exist..Cannot print anything...")			
		
def get_complexity(result_list, dist_var_dict_list, Varset_sym_to_id_dict_list, tolevel):
	print("")
	print("Calculating the complexity of the remaining key space and the distinguisher evaluation complexity")
	print("")
	
	complexity_list = []
	ind = 0 
	for result in result_list:
		size_R = 1
		H_S_Box = 1
		distinguisher_complexity = 0
		mks_size_max = -1*math.inf
		
		kb_count_per_dist = 0
		for r in result[2].keys():
			mks_size = len(r._mks)
			kb_count_per_dist = kb_count_per_dist + mks_size
			mks_size_max = max(mks_size_max,mks_size)
		distinguisher_complexity = mks_size_max
		tot_key_bits_associated_wd_dist = kb_count_per_dist
		
		distinguisher = result[0]
		MKS_VG_dict = result[2]
		
		# Invert the MKS_VG dictionary		
		VG_MKS_dict = {}
		for k,v in MKS_VG_dict.items():
			VG_MKS_dict[v] = k	
		
		# Invert the distinguisher variable symbol to variable index dictionary
		dist_var_dict = dist_var_dict_list[ind]
		indx_symb_dict = {} 
		for k,v in dist_var_dict.items():
			indx_symb_dict[v] = k

		# If there exists variable sets, invert the dictionaries Varset_sym_to_id_dict_list 
		if Varset_sym_to_id_dict_list is not None:
			Varset_sym_to_id_dict = Varset_sym_to_id_dict_list[ind]
			if Varset_sym_to_id_dict is not None:
				Varset_sym_to_id_dict_inv = {}
				for k,v in Varset_sym_to_id_dict.items():
					Varset_sym_to_id_dict_inv[tuple(v)] = k

		# Next, compute the remaining key space complexity		
		for vg in VG_MKS_dict.keys():
			R_vg = 1
			prob_vg = 1	
			for g in vg._vg:
				count = 0
				m = 0
				if(isinstance(g, word_Variable)):
					Rng_g = distinguisher._var_ranges[indx_symb_dict[g._wordvarindx]]
					count = len(Rng_g)					
					m = distinguisher._wordsize
				elif(isinstance(g, variable_Set)):
					varset_indx_l = tuple(sorted([x._wordvarindx for x in g._Varset]))
					count = distinguisher._Varset_symb_itemset_count_dist[Varset_sym_to_id_dict_inv[varset_indx_l]]	
					m = (distinguisher._wordsize)*len(varset_indx_l)				
				prob_vg = prob_vg * (count/(2**m))
			key_size = len(VG_MKS_dict[vg]._mks)
			R_vg = R_vg*(2**key_size)*(prob_vg)*H_S_Box
			size_R = size_R*R_vg
		######################################################################
		# Experimental Code:
		# Generate some message indicating incomplete diffusion. In particular, 
		# if the distinguisher under consideration cannot extract all associated
		# key bits, then we raise an alart message and also indicate how many 
		# keys can be extracted, and how many has to be searched, exhaustively.
		# The remaining key complexity is also adjusted accordingly.   
		
		non_recovered_key_bits = None
		
		st = True
		for d in range(distinguisher._numAttributes):
			st = st & distinguisher._Active[d]
		
		if (not st):	# Incomplete diffusion

			# Count the maximum number of key bits that can be associated with this distinguisher
			
			# Get the distinguisher state index
			lbl = distinguisher._state_idx
			
			# Get all the key addition layers in the cdg towards the ciphertext starting from 
			# the output of the next nonlinear sub-op and count the number of associated key bits 
			cdg_tmp = result[1]
			cdg_tmp.createcdg(fromlevel=lbl, tolevel=tolevel)
			
			levellist = cdg_tmp._levellist
			levellist_sorted = collections.OrderedDict(sorted(levellist.items()))				
			
			# Get to the output of the next non-linear layer
			next_non_linear_level_op = 0
			for ll in levellist_sorted.keys():
				if (ll >= lbl):
					if (levellist_sorted[ll]._isnonlinear is True):
					  next_non_linear_level_op = ll+1
					  break
			# Now, collect the key-addition layers starting from the level to the ciphertext level
			tot_keynode_cnt = 0
			if (tolevel is None):
				tolevel = max(levellist_sorted.keys())
				
			for ll in levellist_sorted.keys():
				if ( (ll >= next_non_linear_level_op) and (ll <= tolevel)):
					if (levellist_sorted[ll]._iskeylevel):
						tot_keynode_cnt = tot_keynode_cnt + levellist_sorted[ll]._nrkeynode		# We just collect the number of associated keynodes
																								# However, we can also collect the keynodes itself.
																								# But, it is not required at this point.

			# Now, see if incomplete diffusion causes some keys not to be revealed
			if (tot_keynode_cnt > tot_key_bits_associated_wd_dist):
				non_recovered_key_bits = tot_keynode_cnt - tot_key_bits_associated_wd_dist
			#print(tot_keynode_cnt)
			#print(tot_key_bits_associated_wd_dist)
			#print(non_recovered_key_bits)
			#pause()
		######################################################################		
		complexity_list.append((distinguisher_complexity, size_R, distinguisher, tot_key_bits_associated_wd_dist, non_recovered_key_bits))			
		ind += 1		

	return complexity_list  

def get_complexity_new(result_list, dist_var_dict_list, Varset_sym_to_id_dict_list, tolevel, practical_threshold, dfatool_mode, key_add_level=None, remaining_key_complexity_agr=None, keynode_set_discovered=None):
	
	print("")
	print("---------------------------------------------------------------------------------")
	print("Calculating the overall complexity of the attacks in multiple steps, if required.")
	print("---------------------------------------------------------------------------------")
	print("")
	
	#print(math.log(practical_threshold, 2))
	#pause()
	
	complexity_list = []
	ind = 0 
	for result in result_list:
		size_R = 1
		H_S_Box = 1
		distinguisher_complexity = 0
		mks_size_max = -1*math.inf
		tot_key_bits_associated_wd_dist = 0   # Total number of key bits associated with the distinguisher
		
		# First, compute the distinguisher evaluation complexity 
		kb_count_per_dist = 0
		for r in result[2].keys():
			mks_size = len(r._mks)
			kb_count_per_dist = kb_count_per_dist + mks_size
			mks_size_max = max(mks_size_max,mks_size)
		distinguisher_complexity = mks_size_max
		
		
		tot_key_bits_associated_wd_dist = kb_count_per_dist
		
		# Update the distinguisher evaluation complexity if some previous remaining key complexity is available for the same key-space
		if (remaining_key_complexity_agr is not None):
			mks_set_tmp = set()
			for r in result[2].keys():
				mks_set_tmp.update(r._mks)
			target_keyset = set(result[1]._levellist[key_add_level]._keynodes.values())
			if (target_keyset == mks_set_tmp):
				distinguisher_complexity = round(math.log(remaining_key_complexity_agr,2))
			
		distinguisher = result[0]
		MKS_VG_dict = result[2]
		
		# Invert the MKS_VG dictionary		
		VG_MKS_dict = {}
		for k,v in MKS_VG_dict.items():
			VG_MKS_dict[v] = k	
		
		# Invert the distinguisher variable symbol to variable index dictionary
		dist_var_dict = dist_var_dict_list[ind]
		indx_symb_dict = {} 
		for k,v in dist_var_dict.items():
			indx_symb_dict[v] = k
		 
		# If there exists variable sets, invert the dictionaries Varset_sym_to_id_dict_list 
		if Varset_sym_to_id_dict_list is not None:
			Varset_sym_to_id_dict = Varset_sym_to_id_dict_list[ind]
			if Varset_sym_to_id_dict is not None:
				Varset_sym_to_id_dict_inv = {}
				for k,v in Varset_sym_to_id_dict.items():
					Varset_sym_to_id_dict_inv[tuple(v)] = k

		# Next, compute the remaining key space complexity			
		for vg in VG_MKS_dict.keys():
			R_vg = 1
			prob_vg = 1	
			for g in vg._vg:
				count = 0
				m = 0
				if(isinstance(g, word_Variable)):
					Rng_g = distinguisher._var_ranges[indx_symb_dict[g._wordvarindx]]
					count = len(Rng_g)					
					m = distinguisher._wordsize
				elif(isinstance(g, variable_Set)):
					varset_indx_l = tuple(sorted([x._wordvarindx for x in g._Varset]))
					count = distinguisher._Varset_symb_itemset_count_dist[Varset_sym_to_id_dict_inv[varset_indx_l]]	
					m = (distinguisher._wordsize)*len(varset_indx_l)				
				prob_vg = prob_vg * (count/(2**m))
			key_size = len(VG_MKS_dict[vg]._mks)
			
			# Update the key_size if the key search space has already been reduced
			if (remaining_key_complexity_agr is not None):
				key_size = math.log(remaining_key_complexity_agr, 2)
			R_vg = R_vg*(2**key_size)*(prob_vg)*H_S_Box
			size_R = size_R*R_vg
	
		######################################################################
		# Experimental Code 1:
		# Generate some message indicating incomplete diffusion. In particular, 
		# if the distinguisher under consideration cannot extract all associated
		# key bits, then we raise an alart message and also indicate how many 
		# keys can be extracted, and how many has to be searched, exhaustively.
		# The remaining key complexity is also adjusted accordingly.   
		
		non_recovered_key_bits = None
		
		st = True
		for d in range(distinguisher._numAttributes):
			st = st & distinguisher._Active[d]
		
		if (not st):	# Incomplete diffusion
			
			# Count the maximum number of key bits that can be associated with this distinguisher
			
			# Get the distinguisher state index
			lbl = distinguisher._state_idx
			
			# Get all the key addition layers in the cdg towards the ciphertext starting from 
			# the output of the next nonlinear sub-op and count the number of associated key bits 
			cdg_tmp = result[1]
			cdg_tmp.createcdg(fromlevel=lbl, tolevel=tolevel)
			
			levellist = cdg_tmp._levellist
			levellist_sorted = collections.OrderedDict(sorted(levellist.items()))				
			
			# Get to the output of the next non-linear layer
			next_non_linear_level_op = None
			for ll in levellist_sorted.keys():
				if (ll >= lbl):
					if (levellist_sorted[ll]._isnonlinear is True):
					  next_non_linear_level_op = ll+1
					  break
			# Now, collect the key-addition layers starting from the level to the ciphertext level
			tot_keynode_cnt = 0
			if (tolevel is None):
				tolevel = max(levellist_sorted.keys())
			
			# A guard 
			if (next_non_linear_level_op is None):
				next_non_linear_level_op = tolevel + 1
			
			for ll in levellist_sorted.keys():
				if ( (ll >= next_non_linear_level_op) and (ll <= tolevel)):
					if (levellist_sorted[ll]._iskeylevel):
						tot_keynode_cnt = tot_keynode_cnt + levellist_sorted[ll]._nrkeynode		# We just collect the number of associated keynodes																	# However, we can also collect the keynodes itself.
																								# But, it is not required at this point.

			# Now, see if incomplete diffusion causes some keys not to be revealed
			if (tot_keynode_cnt > tot_key_bits_associated_wd_dist):
				non_recovered_key_bits = tot_keynode_cnt - tot_key_bits_associated_wd_dist
			#print(tot_keynode_cnt)
			#print(tot_key_bits_associated_wd_dist)
			#print(non_recovered_key_bits)
			#pause()
		######################################################################		
		
		complexity_list.append((distinguisher_complexity, size_R, distinguisher, tot_key_bits_associated_wd_dist, non_recovered_key_bits))			
		ind += 1		

	return complexity_list  

def get_1st_distinguisher(complexity_list, result_list, dist_var_dict_list, Varset_sym_to_id_dict_list, c):
	print("Get the best distinguisher at each stage of attack")
		
	# Create a dictionary of distinguishers keyed by these tuple of attributes
	# This step is for the removal of duplicate distinguishers for which every metric is same 
	# (generally occurs accross key addition steps).
	dist_dict = {}	
	for comp in complexity_list:
		if (comp[3] > 0):      # Sometimes ciphertext layer is counted as a distinguisher. We remove this as no key is associated.
			c2 = float(math.log(comp[1], 2))/float(comp[3])
			c3 = float(comp[0])/float(comp[3])
			c4 = comp[3]
			c5 = comp[4]
			metr_tuple = (comp[0], comp[1], c2, c3, c4, c5)
			dist_dict[metr_tuple] = comp[2]

	#print("here")
	#for d in dist_dict.keys():
	#	print(d[0], math.log(d[1],2), d[2], d[3], d[4], d[5], dist_dict[d]._state_diff_round_idx, dist_dict[d]._state_diff_subop_idx)
	#pause()		
	
	# Throw some of the distinguishers for which evaluation complexity is same as the brute-fource complexity
	complexity_list_refined = []	
	# Now, convert the disctionary again to a list of tuples
	for d in dist_dict.keys():
		# Perform a basic thresholding. Just remove the elements for which d[3] == 1   # this is the only place where the ratios are being used
		if (d[3] < 1.0):
			complexity_list_refined.append((d[0], d[1], d[2], d[3], d[4], d[5], dist_dict[d]))
		elif ( (d[5] is not None) and (d[0] < math.log(practical_threshold, 2)) and (d[0] < c._rkeywidth) ): 		
			# If there is incomplete diffusion, 
			# we still allow distinguishers for which d[3] is 1.
			# only if the complexities are practical and less than the total complexity possible for one round key 
			complexity_list_refined.append((d[0], d[1], d[2], d[3], d[4], d[5], dist_dict[d]))
			#print("here I'm")
			#print(d[0], math.log(d[1],2), d[2], d[3], d[4], d[5], dist_dict[d]._state_diff_round_idx, dist_dict[d]._state_diff_subop_idx)
			#pause() 
	
	
	if(len(complexity_list_refined) > 0):	
		# Now, sort this list using the evaluation complexity as a key
		complexity_list_refined_sorted = sorted(complexity_list_refined, key=lambda x: x[0])

		#for c in complexity_list_refined_sorted:
		#	print(c[0], math.log(c[1], 2), c[2], c[3], c[4], c[5], c[6]._state_diff_round_idx, c[6]._state_diff_subop_idx)
		#pause()
		# Now, search for the distinguisher having best remaining key complexity in the sorted list
		# Here, we consider multiple things, the list traversal starts from the beginning and continues up-to max 3 elements (if exists) 
		# for now. The choice of 3 is an assumption, based on the fact that the last distinguisher should be chosen as near to the ciphertext
		# as possible, to keep the evaluation complexity low. We also found that for most of our test cases, the number of candidates for the 
		# first distinguishers do not cross 3. However, this is indeed an heuristics without any concrete proof. In future, we'll come up with 
		# a more complete algorithm in this respect. 
		 
		search_window_size = 3 
		dist_best_comp = math.inf
		dist_best = None
		cntr = 0
		for c in complexity_list_refined_sorted:
			if (cntr > search_window_size):
				break
			comp_val = math.log(c[1], 2)
			if (comp_val < 0):        # An implementation perspective (negative remaining key entropy is converted to unique key)
				comp_val = 1	 	  # It really, helps in computing the best distinguisher too, by removing some unnecessary complexity increment
			if (dist_best_comp > comp_val):
				dist_best = c
				dist_best_comp = math.log(c[1], 2)
			cntr = cntr + 1;
		#print(dist_best[0], math.log(dist_best[1], 2), dist_best[2], dist_best[3], dist_best[4], dist_best[5], dist_best[6]._state_diff_round_idx, dist_best[6]._state_diff_subop_idx)		
		best_first_distinguisher_details = []   # this is made a list just to keep compatibility with the printing routine.		
		best_first_distinguisher_details.append((dist_best[0], dist_best[1], dist_best[6], dist_best[4], dist_best[5]))

		#Also, return the corresponding structures from the result_list and dist_var_dict_list
		if dist_best[6] is not None:
			b_dis = dist_best[6]
			dist_cdg_mks_detail_struct = None
			dist_var_dict_detail = None
			Varset_sym_to_id_dict_detail = None
			indx = 0
			for ds in result_list:
				ds_tmp = ds[0]
				if(ds_tmp._state_idx == b_dis._state_idx):
					dist_cdg_mks_detail_struct = ds
					break	
				indx = indx + 1
			
			dist_var_dict_detail = dist_var_dict_list[indx]
			Varset_sym_to_id_dict_detail = Varset_sym_to_id_dict_list[indx]
					
			
		return 	best_first_distinguisher_details, dist_cdg_mks_detail_struct, dist_var_dict_detail, Varset_sym_to_id_dict_detail
	else:
		return None
	
def get_fault_complexity(best_distinguisher, dfatool_mode, practical_threshold, remaining_key_complexity_agr, full_key_state_in_each_round):
	print("")
	print("Calculate the number of faults required to do the attack practically")
	print("")
	#---------------------------------------------------------------	
	# Handling multiple faults
	#---------------------------------------------------------------
	# If the mode of the tool allows multiple fault injection or the
	# remaining key space complexity is too high (typically more than
	# 2^50) we allow higher fault multiplicities.   
	fault_multiplicity = 1
	distinguisher = best_distinguisher[0][0][2]
	MKS_VG_dict = best_distinguisher[1][2]
	dist_var_dict = best_distinguisher[2]
	Varset_sym_to_id_dict = best_distinguisher[3]

	size_R = 1
	H_S_Box = 1
	distinguisher_complexity = 0
	mks_size_max = -1*math.inf	

	# Invert the MKS_VG dictionary		
	VG_MKS_dict = {}
	for k,v in MKS_VG_dict.items():
		VG_MKS_dict[v] = k	
	
	# Invert the distinguisher variable symbol to variable index dictionary
	indx_symb_dict = {} 
	for k,v in dist_var_dict.items():
		indx_symb_dict[v] = k
	 
	# If there exists variable sets, invert the dictionaries Varset_sym_to_id_dict_list 
	if Varset_sym_to_id_dict is not None:
		Varset_sym_to_id_dict_inv = {}
		for k,v in Varset_sym_to_id_dict.items():
			Varset_sym_to_id_dict_inv[tuple(v)] = k
	
	# If the attack is an IDFA attack, the calculation is slightly different
	#if (not(distinguisher._if_IDFA_distinguisher) ):
	for vg in VG_MKS_dict.keys():
		R_vg = 1
		prob_vg = 1	
		fault_mult = 1
		for g in vg._vg:
			count = 0
			m = 0
			if(isinstance(g, word_Variable)):
				Rng_g = distinguisher._var_ranges[indx_symb_dict[g._wordvarindx]]
				count = len(Rng_g)					
				m = distinguisher._wordsize
			elif(isinstance(g, variable_Set)):
				varset_indx_l = tuple(sorted([x._wordvarindx for x in g._Varset]))
				count = distinguisher._Varset_symb_itemset_count_dist[Varset_sym_to_id_dict_inv[varset_indx_l]]	
				m = (distinguisher._wordsize)*len(varset_indx_l)				
			prob_vg = prob_vg * (count/(2**m))
		key_size = len(VG_MKS_dict[vg]._mks)			
		# Update the key_size if the key search space has already been reduced
		if ( (remaining_key_complexity_agr != 1) and (full_key_state_in_each_round) ):
			key_size = math.log(remaining_key_complexity_agr, 2)
		R_vg = R_vg*(2**key_size)*(prob_vg)*H_S_Box
		# If the attack is an IDFA attack, the calculation is slightly different
		if (not(distinguisher._if_IDFA_distinguisher) ):
			fault_mult = math.ceil( float( -1*(key_size + math.log(H_S_Box,2)) )/ float( math.log(prob_vg,2) ))
		else:
			rem_keyspace_aftr_one_inj = 2**key_size*(1-prob_vg)
			overlap = float(rem_keyspace_aftr_one_inj**2)/float(2**key_size) 
			redu_fact = float(overlap)/float(rem_keyspace_aftr_one_inj)
			fault_mult = math.ceil( (-1* float(key_size) )/float(math.log((1 - redu_fact))) )
		if (fault_multiplicity <= fault_mult):
			fault_multiplicity = fault_mult		
		size_R = size_R*R_vg					
	return fault_multiplicity	
	
def print_result(complexity_results, output_filename=None):
	print("")
	print("Printing the final Results...")
	print("")	
	
	if (output_filename is not None):
		outfile = open(output_filename, 'w')
		outfile.close()
	
	for result in complexity_results:
		distinguisher_complexity = result[0]
		size_R = result[1]
		distinguisher = result[2]
		non_recovered_key_bits = result[4]
		distinguisher = [distinguisher]
		if (output_filename is not None):
			outfile = open(output_filename, 'a+')
			outfile.write("	Distinguisher Evaluation Complexity (in log scale)			Remaining Key Space Complexity (in log scale)\n")
			# Modified 09_06_2021
			tmpp = math.log(size_R, 2)
			if (tmpp < 0):
				tmpp = 0
			outfile.write("				{}							{}		\n".format( distinguisher_complexity, tmpp )  )
			#outfile.write("				{}							{}		\n".format( distinguisher_complexity, math.log(size_R, 2) )  )
			#################
			if (result[4] is not None):
				outfile.write(" Warning!! Incomplete Diffusion. {} key bits not recovered	\n\n\n".format( result[4] )  )
			outfile.close()
			print_distinguisher_info(distinguisher, print_ranges=True, print_variable_sets=True, output_filename=output_filename )
			outfile = open(output_filename, 'a+')
			outfile.write("\n")
			outfile.write("-----------------------------------------------------------------------------------------------------------\n")
			outfile.write("\n")
			outfile.write("\n")
			outfile.close()
		print("	Distinguisher Evaluation Complexity (in log scale)			Remaining Key Space Complexity (in log scale)")
		# Modified 09_06_2021
		tmpp1 = math.log(size_R, 2)
		if (tmpp1 < 0):
			tmpp1 = 0
		print("				{}							{}		".format( distinguisher_complexity, tmpp1 )  )			
		#print("				{}							{}		".format( distinguisher_complexity, math.log(size_R, 2) )  )
		#################
		if (result[4] is not None):
			print(" Warning!! Incomplete Diffusion;		{}	key bits not recovered	\n".format( result[4] )  )		
		#print_distinguisher_info(distinguisher, print_ranges=True, print_variable_sets=True )
		print("-----------------------------------------------------------------------------------------------------------")
		print("")
		print("") 

def find_tolevel(c, distinguisher_all_details):
	#print("Up to which level should we search...")
	if distinguisher_all_details is None:
		return None
	else:	
		# Here we make one simplifying assumption that the keys are found layerwise and with one distinguisher, a 
		# a complete key layer is determined. May be multiple faults can be required for complexity reduction,
		# (we'll handle multiple fault in later versions). There can be cases where a distinguisher (or fault location)
		# only recovers a part of a key-layer. In such cases, we cannot apply multiple distinguishers in a head on manner.
		# the analysis steps will be a bit different. We shall take care of this in future versions.
		
		# First, determine the key-levels we have discovered  
		MKS_VG_dict = distinguisher_all_details[1][2]
		min_level_foundkey = math.inf
		for tm in MKS_VG_dict.keys():
			#print(tm._mks._whichlevel)
			for tm1 in tm._mks:
				if(tm1._whichlevel < min_level_foundkey):
					min_level_foundkey = tm1._whichlevel
		#print(min_level_foundkey)
		
		# Next, search for the penultimate key level undiscovered from the ciphertext side. 
		# temporarily create a global cdg for this
		cdg_global = CDG(c,cdgtype="dag")
		cdg_global.createcdg(fromlevel=1, tolevel=None)
		
		levellist = cdg_global._levellist
		levellist_sorted = collections.OrderedDict(sorted(levellist.items(), reverse = True))	
		
		tolevel = 0
		start_ind = min_level_foundkey
		for tl in levellist_sorted.keys():
			if (tl < start_ind):
				if(levellist[tl]._iskeylevel):
					tolevel = tl+1
					break
		tolevel = tolevel + 1   # just some syntactical thing
		return tolevel    

if __name__ == '__main__':
	
	# A flag (temporary)
	use_old_arff_flag = int(os.environ.get('USE_OLDDATA_FLAG'))
	print_cdg = int(os.environ.get('PRINT_CDG'))
	
	#----------------------------------------------------------------------
	# Set the input and output folders an set the environment
	#----------------------------------------------------------------------
	ip_folder_1 = os.environ.get('INPUTDIR')
	ip_folder_2 = os.environ.get('OUTPUTDIR')
	ip_folder_3 = os.environ.get('CIPHERDESCDIR')
	
	
	cipher_filename = os.environ.get('CIPHER_FILENAME')
	fault_injection_info = os.environ.get('INFO_STR')
	output_filename = fault_injection_info+"_result" + ".txt"
	
	######New inclusion 06_06_2021
	full_key_state_in_each_rnd = os.environ.get('FULL_KEY_STATE_IN_EACH_ROUND')
	if (full_key_state_in_each_rnd == '0'):
		full_key_state_in_each_round = False
	elif (full_key_state_in_each_rnd == '1'):
		full_key_state_in_each_round = True
	else:
		full_key_state_in_each_round = None # Currently unused	

	#print(full_key_state_in_each_round)
	#pause()			
	##############################
	
	
	
	if (use_old_arff_flag == 1):
		output_filename = None
	
	#----------------------------------------------------------------------
	# Two mode of operations: 
	# dfatool_mode = 0 ==> attack with fault
	# multiplicity (number of injections at the same location) = 1 
	#
	# dfatool_mode = 1 ==> at each distinguisher, allow multiple faults
	# to uniquely extract the keys.
	#----------------------------------------------------------------------
	
	# To be implemented.....
	dfatool_mode = 0
	practical_threshold = 2**50
	
	#----------------------------------------------------------------------
	# Identify the potential distinguishers corresponding a fault injection
	#----------------------------------------------------------------------
	dataread_start = time.time()
	dataset_list = read_input(ip_folder_1, ip_folder_2)
	dataread_stop = time.time()
	
	distinguisher_identification_time_start = time.time()
	distinguisher_list = identify_distinguishers(dataset_list)
	#print_distinguisher_info(distinguisher_list, print_ranges=True, print_variable_sets=True )
	distinguisher_identification_time_stop = time.time()
	
	#----------------------------------------------------------------------
	# Now, construct Cipher Dependency Graphs (CDG) for each distinguisher
	# and calculate their evaluation complexities.	
	#----------------------------------------------------------------------
	cdg_analysis_time_start = time.time()
	c = Cipher()
	c.__getattr__(cipher_filename)
	result_list, dist_var_dict_list, Varset_sym_to_id_dict_list = get_distinguisher_eval_complexity(c, distinguisher_list)
						
	#--------------------------------------------------------------------------
	# Finally, compute the remaining key space size for suitable distinguishers
	# and estimate the reasonable number of injections required to make a 
	# practical attack.	(without considering extra key-schedule equations)	
	#-------------------------------------------------------------------------- 	
	tolevel = None
	complexity_results = get_complexity(result_list, dist_var_dict_list, Varset_sym_to_id_dict_list, tolevel)
	#print_result(complexity_results, output_filename)
	cdg_analysis_time_stop = time.time()

	
	
	################################ Experimental ##############################
	# Select stage by stage distinguishers for AES
	#### Certain details to be ported as input later ###########
	full_key_state_size = 128							    # Size of the full key state
	
	
	# TODO: create a structure indicating the dependency of key states
	# Ideal thing will be a key schedule graph. But for the time being
	# and to maintain simplicity, we suggest for a array/dictionary-like
	# structure. However, still this development is delayed upto the
	# next version. 
	dependent_key_states = True				#unused
	######New inclusion 06_06_2021 (uncomment to get the old version)
	#full_key_state_in_each_round = False			        # Whether the full key state is exposed in each round or not
	#####################################
	key_state_recovered = 0								# Keeps track of the key state recovered in each iteration
														# If full state is recovered (of course non-uniquely) and
														# there are still some distinguisher left, it goes on for further reducing the
														# complexity, up to the fault injection location. 
														# In contrary, if distinguisher set is emptied before full key is 
														# found, it asks for more fault injection or injection at a different 
														# location .  If full key is found its fine, otherwise, it reports whatever its has found.  
	
	itr_cnt = 0                                             
	best_distinguisher = None
	remaining_key_complexity_agr = 1 
	distinguisher_evaluation_complexity_agr = 1
	key_add_level = None
	fault_multiplicity_aggr = 1
	
	keynode_set_discovered = None
	keynode_set_reduced_comp = None			#unused
	
	c = Cipher()
	c.__getattr__(cipher_filename)
	
	while(True):
		itr_cnt = itr_cnt + 1


		# Up to which level should we search
		tolevel = find_tolevel(c, best_distinguisher)		
		
		if tolevel is not None:
			key_add_level = tolevel - 2
		else:
			key_add_level = None	
		
		result_list, dist_var_dict_list, Varset_sym_to_id_dict_list = get_distinguisher_eval_complexity(c, distinguisher_list, tolevel)			
		
				
		# Get the best distinguisher for a level
		if ( (full_key_state_in_each_round) and (key_state_recovered == full_key_state_size) ):
			complexity_results_extended = get_complexity_new(result_list, dist_var_dict_list, Varset_sym_to_id_dict_list, tolevel, practical_threshold, dfatool_mode, key_add_level, remaining_key_complexity_agr, keynode_set_discovered)
		else:
			complexity_results_extended = get_complexity_new(result_list, dist_var_dict_list, Varset_sym_to_id_dict_list, tolevel, practical_threshold, dfatool_mode)
		best_distinguisher = get_1st_distinguisher(complexity_results_extended, result_list, dist_var_dict_list, Varset_sym_to_id_dict_list, c)
		
		#pause()
		
		#if best_distinguisher is not None:
		#	print(best_distinguisher[3])
		#	print(best_distinguisher[0][0][2]._state_diff_round_idx)
		#	print(best_distinguisher[0][0][2]._state_diff_subop_idx)
		#pause()
		
		# What happens if we are allowed to put multiple faults 
		fault_multiplicity = 1
		if best_distinguisher is not None:
			if (dfatool_mode == 1):
				fault_multiplicity = get_fault_complexity(best_distinguisher, dfatool_mode, practical_threshold, remaining_key_complexity_agr, full_key_state_in_each_round)
				print("")
				print("Faults required to unify the key is")
				print(fault_multiplicity)
				print("")
				if (fault_multiplicity > 1):
					fault_multiplicity_aggr = fault_multiplicity_aggr + (fault_multiplicity - 1)
			elif (best_distinguisher[0][0][2]._if_IDFA_distinguisher):
				fault_multiplicity = get_fault_complexity(best_distinguisher, dfatool_mode, practical_threshold, remaining_key_complexity_agr, full_key_state_in_each_round)			
				print("")
				print("IDFA Distinguisher found. Number of faulty to unify the key is given below..")
				print(fault_multiplicity)
				#pause()
				print("")
				if (fault_multiplicity > 1):
					fault_multiplicity_aggr = fault_multiplicity_aggr + (fault_multiplicity - 1)
					
								
		# Save the keyset whose complexity is reduced with the current distinguisher under consideration
		if best_distinguisher is not None:
			keynode_set_discovered = set()
			mks_vg_best_distinguisher = best_distinguisher[1][2]
			for r in mks_vg_best_distinguisher.keys():
				keynode_set_discovered.update(r._mks)	
		
		# Find the overall attack complexity......
		if best_distinguisher is not None:
			bd = best_distinguisher[0][0]
			distinguisher_evaluation_complexity_agr = max(distinguisher_evaluation_complexity_agr, 2**(bd[0]))
			if (not full_key_state_in_each_round):
				if (dfatool_mode == 1):
					r_comp_this_dist = 1
				else:
					r_comp_this_dist = bd[1]	
				if (bd[1] < 1):
					remaining_key_complexity_agr = remaining_key_complexity_agr * 1
				else:
					remaining_key_complexity_agr = remaining_key_complexity_agr * r_comp_this_dist	
			else:
				if ( (dfatool_mode == 1) or  bd[2]._if_IDFA_distinguisher):
					r_comp_this_dist = 1
				else:
					r_comp_this_dist = bd[1]					
				if (bd[1] < 1):
					remaining_key_complexity_agr = 1
				else:
					remaining_key_complexity_agr = r_comp_this_dist				
		
		# Find how many keys have been recovered so far
		if best_distinguisher is not None:
			MKS_VG_dict_tmp = best_distinguisher[1][2]
			for tm in MKS_VG_dict_tmp.keys():
				key_state_recovered = key_state_recovered + len(tm._mks)
		
		
		# Print the distinguisher for this current stage at a file
		fldrname = "attack_dist/"		#modified by adding the directory 09.06.2021
		if best_distinguisher is not None:
			op_file = fldrname + "dist_"+str(itr_cnt)+"_file.txt"
			print_result(best_distinguisher[0], op_file)
		else:
			print("No distinguisher found....")			

		
		# Termination conditions
		if ( (best_distinguisher is None) ):
			if ( (key_state_recovered == full_key_state_size) ):
				print("")
				print("Successful Attack")
				print("")
			elif(key_state_recovered < full_key_state_size):
				remaining_key_bits = full_key_state_size - key_state_recovered
				remaining_key_complexity_agr = remaining_key_complexity_agr * 2**(remaining_key_bits)
				print("")
				print("Sorry!! Full key state cannot recovered with this fault")
				print("We have recovered information about {} bits of keys among total {} bits".format( key_state_recovered, full_key_state_size ) )
				print("So, an exhaustive search of {} bits is still required".format( remaining_key_bits ))	
				print("You should try another fault location to extract the remaining key bits")		
				print("")
			break
		elif( (best_distinguisher is not None) ):
			if ( (key_state_recovered == full_key_state_size) and not (best_distinguisher[0][0][2]._if_IDFA_distinguisher) and (best_distinguisher[0][0][4] is None) ):
				print("")
				print("I think I can reduce the key entropy further. Continuing...")
				print("")
			if ( (key_state_recovered == full_key_state_size) and (remaining_key_complexity_agr == 1) ):
				print("")
				print("Attack Successful")
				print("")
				break	
			if ( (best_distinguisher[0][0][2]._if_IDFA_distinguisher) ):
				# There is an assumption at this point. For simplicity we assume that
				# IDFA distinguishers only occur when the complete state is active.
				# The identification of IDFA distinguishers were defined in this code
				# for all active state (see: Distinguisher_Identifier.py). However, this
				# might not be the only case in general. We are waiting for the right example.
				print("")
				print("I found an IDFA distinguisher. You have to inject this many faults to get the key")
				print("")
				break					
			if (best_distinguisher[0][0][4] is not None):
				# If a distinguisher allows pertial key recovery due to incomplete diffusion
				# We do not go and seach for further distinguishers.
				if(key_state_recovered < full_key_state_size):
					remaining_key_bits = full_key_state_size - key_state_recovered
					remaining_key_complexity_agr = remaining_key_complexity_agr * 2**(remaining_key_bits)
					print("")
					print("Sorry!! Full key state cannot recovered with this fault")
					print("We have recovered information about {} bits of keys among total {} bits".format( key_state_recovered, full_key_state_size ) )
					print("So, an exhaustive search of {} bits is still required".format( remaining_key_bits ))	
					print("You should try another fault location to extract the remaining key bits")		
					print("")					
					break					
			
		
	print("")
	print("Overall Evaluation Complexity (in log scale): {} ".format( math.log(distinguisher_evaluation_complexity_agr, 2)) )
	print("")
	if (dfatool_mode == 1 ):
		print("Faults required for this attack is: {} ".format(fault_multiplicity_aggr) )
	if (best_distinguisher is not None):
		if ( (best_distinguisher[0][0][2]._if_IDFA_distinguisher) ):
			print("Attack with IDFA distinguisher..")
			print("Faults required for this attack is: {} ".format(fault_multiplicity_aggr) )
	if (remaining_key_complexity_agr != 1):
		print("Overall Remaining Key Space Complexity (in log scale): {} " .format( math.log(remaining_key_complexity_agr, 2) ) )
	else:
		print("Overall Remaining Key Space Complexity (in normal scale): 1 " )	
	print("")	
	############################################################################
	
	
	
	"""
	############################# Experimental code ########################################################################
	
	#### Certain details to be ported as input later ###########
	full_key_state_size = 128							    # Size of the full key state
	full_key_state_in_each_round = False			        # Whether the full key state is exposed in each round or not
	
	
	key_state_recovered = 0							# Keeps track of the key state recovered in each iteration
	                                                # If full state is recovered (of course non-uniquely) and
	                                                # there are still some distinguisher left, it goes on for further reducing the
	                                                # complexity, up to the fault injection location. 
	                                                # In contrary, if distinguisher set is emptied before full key is 
	                                                # found, it can search up to the fault injection location.  If full key is found its
	                                                # fine, otherwise, it reports whatever its has found.  
	itr_cnt = 0                                             
	best_distinguisher = None
	remaining_key_complexity_agr = 1 
	distinguisher_evaluation_complexity_agr = 1
	
	c = Cipher()
	c.__getattr__(cipher_filename)	
	
	while(True):
		pause()
		itr_cnt = itr_cnt + 1

		# Up to which level should we search
		tolevel = find_tolevel(c, best_distinguisher)		
		
		
		result_list, dist_var_dict_list, Varset_sym_to_id_dict_list = get_distinguisher_eval_complexity(c, distinguisher_list, tolevel)			
		
		# Get the best distinguisher for a level
		complexity_results_extended = get_complexity_new(result_list, dist_var_dict_list, Varset_sym_to_id_dict_list, tolevel)
		best_distinguisher = get_1st_distinguisher(complexity_results_extended, result_list, dist_var_dict_list)
		
		# Find the overall attack complexity......
		if best_distinguisher is not None:
			bd = best_distinguisher[0][0]
			distinguisher_evaluation_complexity_agr = max(distinguisher_evaluation_complexity_agr, 2**(bd[0]))
			if (bd[1] < 1):
				remaining_key_complexity_agr = remaining_key_complexity_agr * 1
			else:
				remaining_key_complexity_agr = remaining_key_complexity_agr * bd[1]	
		
		# Find how many keys have been recovered so far
		if best_distinguisher is not None:
			MKS_VG_dict_tmp = best_distinguisher[1][2]
			for tm in MKS_VG_dict_tmp.keys():
				key_state_recovered = key_state_recovered + len(tm._mks)
				
		# Print the distinguisher for this current stage at a file
		if best_distinguisher is not None:
			op_file = "dist_"+str(itr_cnt)+"_file.txt"
			print_result(best_distinguisher[0], op_file)
		else:
			print("No suitable distinguisher found. Cannot attack with this fault...")			

			
		# Termination condition.......
		if ( (best_distinguisher is None) or (key_state_recovered == full_key_state_size) ):
			# If full key state is not recovered and best distinguisher is not found
			# that implies that the distinguisher list is exhausted. At this point,
			# if tolevel returns a keylevel (we should see tolevel-2),
			# which is at the fault injection round, then we know that
			# we have reached the fault injection point where no entropy reduction happens 
			# (except a little which is not that useful). Here we stop.
			# However, if full key state is not extracted, we raise a warning message.
			# stating how many key bits are yet to be recovered.
			
			if(key_state_recovered < full_key_state_size):
				remaining_key_bits = full_key_state_size - key_state_recovered
				remaining_key_complexity_agr = remaining_key_complexity_agr * 2**(remaining_key_bits)
				print("")
				print("Sorry!! Full key state cannot recovered with this fault")
				print("We have recovered total {} bits of keys among total {} bits".format( key_state_recovered, full_key_state_size ) )
				print("So, an exhaustive search of {} bits is still required".format( remaining_key_bits ))	
				print("You should try another fault location to extract the remaining key bits")		
				print("")
			break
	
	print("")
	print("Overall Evaluation Complexity (in log scale): {} ".format( math.log(distinguisher_evaluation_complexity_agr, 2)) )
	print("")
	print("Overall Remaining Key Space Complexity (in log scale): {} " .format( math.log(remaining_key_complexity_agr, 2) ) )
	print("")
	"""
	
	
	
	
	
	"""
	# Time Elapsed
	print("Time to process the .arff (purely an overhead and will be removed in future versions..)")
	print(dataread_stop - dataread_start)
	print("")
	
	print("Time to find distinguishers (only rngChk time is included here...Data mining time is higher..)")
	print(distinguisher_identification_time_stop - distinguisher_identification_time_start)
	print("")
	
	print("Time to analyze cdgs and find the attacks (includes printing the graphs which is a pure overhead)")
	print(cdg_analysis_time_stop - cdg_analysis_time_start)
	print("")
	"""
