import os
import sys
import shutil
import time
import re
import math
import getopt
import collections
import glob
import warnings
import networkx as nx
import subprocess

def pause():
	programPause = input("Press the <ENTER> key to continue...")

def clear_folder(folder_path):
	folder = folder_path
	for filename in os.listdir(folder):
		file_path = os.path.join(folder, filename)
		try:
			if os.path.isfile(file_path) or os.path.islink(file_path):
				os.unlink(file_path)
			elif os.path.isdir(file_path):
				shutil.rmtree(file_path)
		except Exception as e:
			print('Failed to delete %s. Reason: %s' % (file_path, e))	

clear_folder('results')

ip_folder_1 = "arff/"
filename_list_arff = []
for file in os.listdir(ip_folder_1):
	if file.endswith(".arff"):
		filename_list_arff.append(os.path.join(ip_folder_1, file))

for filename in filename_list_arff:
	print(filename)
	linelist_mod = []
	data = []
	zerocols = []
	varcount = 0
	
	fname = filename
	fname = fname[5:]
	fname = fname[:-5]
	outfilename = fname + '.tab'
	outfilename = 'tabfiles/' + outfilename
	
	linelist =  open(filename, 'rU').read().splitlines() 
	linelist = list(filter(None, linelist))
	startflag = False
	for line in linelist:
		if (line.startswith('@data')):
			startflag = True
			continue
		if (startflag):
			data.append(line)
	for line in data:
		delimiters = ",", " ", "+"
		regexPattern = '|'.join(map(re.escape, delimiters))
		llist = re.split(regexPattern, line)
		tokens1 = list(filter(None, llist))
		varcount = len(tokens1)	
	colsum = [0]*varcount
	
	for line in data:
		delimiters = ",", " ", "+"
		regexPattern = '|'.join(map(re.escape, delimiters))
		llist = re.split(regexPattern, line)
		tokens1 = list(filter(None, llist))
		for v in range(varcount):
			colsum[v] = colsum[v] + int(tokens1[v])	

	for line in data:
		delimiters = ",", " ", "+"
		regexPattern = '|'.join(map(re.escape, delimiters))
		llist = re.split(regexPattern, line)
		tokens1 = list(filter(None, llist))
		varcount = len(tokens1)
		mod_line = ''
		for v in range(varcount):
			if ( not(colsum[v] == 0) ):
				tmp = "V"+ str(v) + "=" + str(tokens1[v])
				mod_line = mod_line + tmp + ' '
		mod_line = mod_line + '\n'		 	
		linelist_mod.append(mod_line)
	outf = open(outfilename, "w")
	for l in linelist_mod:
		outf.write(l)
	outf.close()

#pause()

ip_folder_2 = "tabfiles/"
op_folder_inter = "results_inter/"
filename_list_tab = []
for file in os.listdir(ip_folder_2):
	if file.endswith(".tab"):
		filename_list_tab.append(os.path.join(ip_folder_2, file))

for filename in filename_list_tab:
	print(filename)
	fname = filename
	fname = fname[9:]
	fname = fname[:-4]
	outfilename = fname + '.itm'
	outfilename = op_folder_inter + outfilename
	#command_str = "./src/fpgrowth -tm -s0.38 -c100 -m2 -v  [%%a, ] -Z %s %s" %(filename, outfilename)
	#command_str = "./src/fpgrowth -tm -s0.38 -ec -d100 -m2 -v\" %%e\" -Z %s %s" %(filename, outfilename)
	#command_str = "./src/fpgrowth -tm -s6.25 -m2 -v\" %%s\" -Z %s %s" %(filename, outfilename)
	command_str = "./itemset_mining_engine/fpgrowth/src/fpgrowth -tm -s0.38 -m2 -v\" %%s\" -Z %s %s" %(filename, outfilename)
	subprocess.call(command_str, shell=True)
	#pause()

# Final file formatting
op_folder_fin = "results/"
filename_list_itm = []
for file in os.listdir(op_folder_inter):
	if file.endswith(".itm"):
		filename_list_itm.append(os.path.join(op_folder_inter, file))

for filename_itm in filename_list_itm:
	print(filename_itm)
	fname = filename_itm
	fname = fname[14:]
	fname = fname[:-4]
	tok_fname = fname.split("_")
	fname_itemset = tok_fname[0]+"_"+tok_fname[4]+"_"+tok_fname[5]
	outfilename = fname_itemset + '.itemset'
	outfilename = op_folder_fin + outfilename	
	if(os.stat(filename_itm).st_size == 0):
		#print(filename_itm)
		pass
	else:
		#print(filename_itm)
		varset_cnt_dict = {}
		linelist_fin =  open(filename_itm, 'rU').read().splitlines() 
		linelist_fin = list(filter(None, linelist_fin))
		#print(linelist_fin)
		for ln in linelist_fin:
			#print(ln)
			delimiters = ",", " ", "+"
			regexPattern = '|'.join(map(re.escape, delimiters))
			tklist = re.split(regexPattern, ln)
			tokens1 = list(filter(None, tklist))
			tokens1 = tokens1[:-1] 	# remove the probability value, we don't need it
			#print(tokens1)	
			sep = '='
			tokens2 = [str(tk.split(sep, 1)[0]) + ":" + str(tk.split(sep, 1)[1]) for tk in tokens1]
			vars_in_tk = [tk.split(sep, 1)[0] for tk in tokens1]
			vars_in_tk_idx = [int(tk[1:]) for tk in vars_in_tk]
			vars_in_tk_sorted = sorted(zip(vars_in_tk_idx, vars_in_tk))
			vars_in_tk_sorted = tuple([element for _, element in vars_in_tk_sorted])
			tk_sorted = sorted(zip(vars_in_tk_idx, tokens2))
			tk_sorted = [element for _, element in tk_sorted]
			#print(vars_in_tk)
			#print(vars_in_tk_idx)
			#print(vars_in_tk_sorted)
			#print(tk_sorted)
			#pause()
			if vars_in_tk_sorted in varset_cnt_dict.keys():
				varset_cnt_dict[vars_in_tk_sorted].append(tk_sorted)	
			else:
				varset_cnt_dict[vars_in_tk_sorted] = [(tk_sorted)]	
		
		#for k in varset_cnt_dict.keys():
		#	print(k, (varset_cnt_dict[k]))
		
		outf = open(outfilename, "w")
		for k in varset_cnt_dict.keys():
			k_str = k[0]
			for ks in k[1:]:
				k_str = k_str + " " + ks
			outf.write(k_str)
			outf.write(" ,")
			outf.write(str(len(varset_cnt_dict[k])))
			outf.write("\n")
			for varlist in varset_cnt_dict[k]:
				outf.write("#")
				varlist_str = ""
				for vs in varlist:
					varlist_str = varlist_str + " " + vs 
				outf.write(varlist_str)
				outf.write("\n")	
		outf.close()		
		#pause()

		
	#pause()

# Clear the temporary folders
clear_folder('results_inter')
clear_folder('tabfiles')
