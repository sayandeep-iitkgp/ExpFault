from __future__ import division, print_function
from __future__ import absolute_import

import os
import sys
import shutil
import time
import re
import math
import getopt
import collections
import glob
import warnings
import networkx as nx
import pygraphviz as pgv
#import javabridge
import arff

from queue import *
from enum import Enum
from networkx import *
from networkx.drawing.nx_agraph import graphviz_layout
import matplotlib.pyplot as plt

#import weka.core.jvm as jvm
#from weka.core.converters import Loader
#from weka.core.converters import *



class SimpleDataSet (object):
	r""" Parse an .arff file and store all necessary info inside a python object.
	This is done to refrain using python-weka wrapper continuously. 
	The wrapper is not very well-documented and we found it rather difficult to use.
	It is used here only once to read out the .arffs."""
	
	def __init__(self):
		self._numAttributes = 0
		self._numAttributeValues = 0
		self._numInstances = 0
		self._varlist = []
		self._var_data_dist = {}
		self._exists_Varset = False
		self._numVarsets = None
		self._Varsetlist = None
		self._Varset_itemset_count_dist = None
		self._Varset_symb_itemset_count_dist = None
		
		self._ciphername = None
		self._Nr = 0							# Number of iterative rounds
		
		self._wordsize = 0						# Variable wordsize (how many bits) considered during 
												# fault simulation. 
												# Generally the width is same with the S-Box input/output 
												# width in our tool 
		
		self._Nvar = 0							# Number of word-level variables					
		
		self._Nsubops = 0						# Number of different sub-operations 						
		
		self._state_diff_round_idx = 0			# Round index of the current state differential
		
		self._state_diff_subop_idx = 0			# Sub-op index of the current state differential
		
		self._state_idx = 0						# Serial index of the state-differential. This becomes the level of a state in the cdg graphs
												
	def __getattr__(self, filename):
		#loader = Loader(classname="weka.core.converters.ArffLoader")
		#data = loader.load_file(filename)
		
		data = arff.load(open(filename, 'r'))
		
		#print(data)
		
		# extract some useful info from the .arff file...
		# print(data['attributes'][0])
		
		#self._numAttributes = data.num_attributes
		self._numAttributes = len(data['attributes'])
		#self._numAttributeValues = data.attribute(0).num_values
		self._numAttributeValues = len(data['attributes'][0][1])
		#self._numInstances = data.num_instances
		self._numInstances = len(data['data'])
		self._varlist = []
		self._var_data_dist = {}
		#self._varlist = [data.attribute(i).name for i in range(self._numAttributes)]
		self._varlist = [data['attributes'][i][0] for i in range(self._numAttributes)]
		
		tmp_list = []
		for i in range(self._numInstances):
			#inst = [int(k) for k in list(data.get_instance(i))]
			inst = [int(k) for k in data['data'][i]]
			tmp_list.append(inst)	
		tmp_list = list(map(list, zip(*tmp_list)))		# take transpose of the list of lists (this line takes time)
		
		for i in range(self._numAttributes):
			self._var_data_dist[i] = tmp_list[i]			  		

	def get_cipher_info (self, filename):
		print("Getting cipher information from the comment lines")
		print("The first line contains the cipher-related info along with round id and sub-op number") 
		print("of the state-differential under consideration. The second line contains the complete")
		print("description of the cipher rounds in terms of sub-op indices.")
		print("")
		print("")
		
		# Get the .cipher file inside the buffer and break it by newlines
		linelist =  open(filename, 'rU').read().splitlines() 
		
		# Remove empty lines and comment lines from the list
		linelist = list(filter(None, linelist))
		linelist = [x for x in linelist if x.startswith('%')]		
		linelist = [re.sub('[%]', '', line) for line in linelist]
		
		ipline = linelist[0]
		tokens = ipline.rsplit()
		self._ciphername = tokens[0]
		self._Nr = int(tokens[1])
		self._wordsize = int(tokens[2])
		self._Nvar = int(tokens[3])
		self._Nsubops = int(tokens[4])
		self._state_diff_round_idx = int(tokens[5])
		self._state_diff_subop_idx = int(tokens[6])			
		self._state_idx = int(tokens[7])

	def get_itemsets(self,itemset_fname):
		print("		",itemset_fname)
		print("")
		
		linelist =  open(itemset_fname, 'rU').read().splitlines()
		linelist = list(filter(None, linelist))
		linelist = [x for x in linelist if not x.startswith('#')] 
		
		self._exists_Varset = True
		self._numVarsets = len(linelist)
		self._Varsetlist = []
		self._Varset_itemset_count_dist = {}
		self._Varset_symb_itemset_count_dist = {}
		
		for line in linelist:
			tokens = line.split(",")
			vset = (tokens[0].rsplit())
			self._Varsetlist.append(vset)
			self._Varset_itemset_count_dist[self._Varsetlist.index(vset)] = int(tokens[1])
			self._Varset_symb_itemset_count_dist[tuple(vset)] = int(tokens[1])

	def __repr__(self):
		print("")
		print(self._ciphername)
		print(self._Nr)
		print(self._wordsize)
		print(self._Nvar)
		print(self._Nsubops)
		print(self._state_diff_round_idx)
		print(self._state_diff_subop_idx)
		print(self._state_idx)
		
		print(self._numAttributes)
		print(self._numAttributeValues)
		print(self._numInstances)
		print(self._varlist)
		print(self._numVarsets)
		print(self._Varsetlist)
		print(self._Varset_itemset_count_dist)
		print(self._Varset_symb_itemset_count_dist)
			
class State_Differential(SimpleDataSet):
	r"""This is the state differential class which encapsulates all necessary information
	one requires to sense a successful fault attack and calculate its complexity.
	Currently it includes two very generic albeit basic methods for identifying
	distinguisgers from data. However, more methods can be added and will be
	added eventually."""
	
	def __init__(self, dataset):
		
		SimpleDataSet.__init__(self)	# Inherit all attributes of the SimpleDataSet Class 
		self.__dict__.update(dataset.__dict__)
		
		self._var_ranges = {}			# Range of each variable 
		
		self._Active = None
		
		self._H_max = 0					# Maximum possible entropy for a state differential.
			
		self._H_ind = 0					# Entropy after range calculation
		
		self._H_acc = None				# Entropy if there exists variable sets	
		
		self._H_state = 0				# Minimum entropy of the state
		
		self._if_distinguisher = False	# If the state qualifies as a distinguisher	
		
		self._if_IDFA_distinguisher = False	# Whether the distinguisher is an impossible differential distinguisher
											# It is used only if "self._if_distinguisher = True". The logic is:
											# "If all the state differential variables have 1,2 (same number of) specific value(s)
											# missing, we can use it as an impossible differential distinguisher. Although,
											# the definition is a bit restricted, it worked fine for the example we have
											# encountered so far (The IDFA attacks on AES and LED)."											

	def view_attr(self):
		self.__repr__()
		print(self._var_ranges)
		print(self._Active)
		print(self._H_max)
		print(self._H_ind)
		print(self._H_acc)
	
	def range_check(self):
		#print("")
		#print("Applying Range Check Function....")
		#print("")
		
		self._Active = [True]*self._numAttributes
		
		# calculate the variable ranges, probability distribution of each variable 
		# and the entropy of state diffential considering each variable is statistically independent		
		for i in range(self._numAttributes):
			Vallist = self._var_data_dist[i]
			Range = [0]*self._numAttributeValues
			maskarr = [0]*self._numAttributeValues
			prob_dist = [0]*self._numAttributeValues
			entropy_var = 0
			for j in Vallist:
				Range[j] = Range[j] + 1
			tot = sum([1 for x in Range if x > 0])
			for j in range(self._numAttributeValues):
				if (Range[j] > 0):
					maskarr[j] = 1
			for j in range(self._numAttributeValues):
				prob_dist[j] = maskarr[j]/tot
			for j in range(self._numAttributeValues):
				if ((prob_dist[j] == 1) and (j == 0)):     # 0 differential does not return any key 
					self._Active[i] = False				   # Trying to capture incomplete diffusion here.
			if(self._Active[i]):
				for x in prob_dist:
					if (x != 0):
						entropy_var += x*math.log(x, 2)
			self._H_ind += entropy_var					
			self._var_ranges[self._varlist[i]] = [j for j in range(self._numAttributeValues) if Range[j] > 0]					
	
		"""
		self._Active = [True]*self._numAttributes
		
		# calculate the variable ranges, probability distribution of each variable 
		# and the entropy of state diffential considering each variable is statistically independent
		for i in range(self._numAttributes):
			Vallist = self._var_data_dist[i]
			Range = [0]*self._numAttributeValues
			prob_dist = [0]*self._numAttributeValues
			entropy_var = 0
			for j in Vallist:
				Range[j] = Range[j] + 1
			for j in range(self._numAttributeValues):
				prob_dist[j] = Range[j]/self._numInstances
			for j in range(self._numAttributeValues):
				if (prob_dist[j] == 1):
					self._Active[i] = False
			if(self._Active[i]):		
				for x in prob_dist:
					if (x != 0):
						entropy_var += x*math.log(x, 2)
			self._H_ind += entropy_var					
			self._var_ranges[self._varlist[i]] = [j for j in range(self._numAttributeValues) if Range[j] > 0]	
		"""
		self._H_ind = -1 * self._H_ind
			
	def cal_Hmax(self):
		for i in range(self._numAttributes):
			entropy = 0
			if(self._Active[i]):
				prob = 1/(2**self._wordsize)
				entropy = (self._numAttributeValues)*(prob*math.log(prob, 2))
				self._H_max += entropy
		self._H_max = -1* self._H_max	
	
	def miner(self):
		#print("")
		#print("Applying Miner Function....")
		#print("")
		self._H_acc = 0
		if (self._Varset_itemset_count_dist is not None):
			for v in self._Varset_itemset_count_dist:
				H_assn_v = 0
				prob = 1/(self._Varset_itemset_count_dist[v])
				for j in range(self._Varset_itemset_count_dist[v]):
					H_assn_v = H_assn_v + (prob*math.log(prob, 2))
				self._H_acc += H_assn_v
			self._H_acc = -1 * self._H_acc
	
	def check_distinguisher(self):
		#print("")
		#print("Checking if the state differential qualifies as a distinguisher...")
		#print("")
		self.range_check()
		self.cal_Hmax()
		if (self._exists_Varset):
			self.miner()
		else:
			self._H_acc = math.inf
		self._H_state = min(self._H_ind, self._H_max, self._H_acc)	
		if (self._H_state < self._H_max):
			self._if_distinguisher = True
		if 	(self._if_distinguisher and not (self._exists_Varset)):  # Check if it an IDFA distinguisher
			self.check_if_IDFA_distinguisher()						 # Again, if there are variable sets, we need not to consider IDFA.
	
	def check_if_IDFA_distinguisher(self):
		# Checks if the distinguisher is an IDFA distinguisher
		# IMP: If there is incomplete diffusion, we do not consider
		# Impossible Differentials.
		# Note that, this is a coding decision taken and can be changed
		# We have considered this just to keep matters simple.
		# Also, we have not found any example of IDFA attack with a incompletely defused state.
		threshold_for_IDFA_sel = 2
		pos_val_set = set([x for x in range(self._numAttributeValues)])
		set_diff_list = []
		all_active = True
		for i in range(self._numAttributes):
			all_active = all_active & self._Active[i]
		if (all_active):		
			for i in range(self._numAttributes):
				range_set = set(self._var_ranges[self._varlist[i]])
				set_diff = list(pos_val_set.difference(range_set))
				set_diff_list.append(set_diff)
			cnt = 0		
			for set_diff in set_diff_list:
				if (len (set_diff) <= threshold_for_IDFA_sel):
					cnt = cnt + 1
			if (cnt ==  len(set_diff_list)):
				self._if_IDFA_distinguisher = True

def read_input(ip_folder_1, ip_folder_2):
	
	#-------------------------------------------------------------------
	# First, collect all input filenames from two input folders
	#-------------------------------------------------------------------
	
	filename_list_arff = []
	for file in os.listdir(ip_folder_1):
		if file.endswith(".arff"):
			filename_list_arff.append(os.path.join(ip_folder_1, file))	
	
	filename_list_results = []
	for file in os.listdir(ip_folder_2):
		if file.endswith(".itemset"):
			filename_list_results.append(os.path.join(ip_folder_2, file))	
	
	#------------------------------------------		
	# Now, read the .arffs and .itemset files
	#-------------------------------------------				
	dataset_list = []
	#jvm.start()
	#os.system('clear')									# jvm.start() prints unnecessary info.  
	#print_heading()										# Let's get rid of them.
	
	#print("Step 1: Distinguisher Identifier Starts...")
		
	arff_processed = 0
	for filename in filename_list_arff:
		dataset = SimpleDataSet()
		dataset.__getattr__(filename)
		dataset.get_cipher_info(filename)	# We also need to extract some basic cipher level information from the metadata of the .arffs
		print()
		arff_processed = arff_processed + 1
		print(".arff processed:%d" %(arff_processed))
		#fname = re.sub('\.arff$', '', filename)	
		#fname = fname[len(ip_folder_1)+1:]				
		# A crucial question here is that whether there is an .itemset file corresponding
		# to each .arff. Missing .itemset files imply that no itemsets can be generated
		fname = str(dataset._ciphername)+"_"+str(dataset._state_diff_round_idx)+"_"+str(dataset._state_diff_subop_idx)+ ".itemset"
		fname = ip_folder_2 + "/" +fname
		if(os.path.isfile(fname)):						# in those case. So, we just check this.  
			print("")
			print("		Itemsets exists. Reading the Itemset file...")
			dataset.get_itemsets(fname)
		dataset_list.append(dataset)
	#jvm.stop()
	
	return dataset_list

def identify_distinguishers(dataset_list):
	
	distinguisher_list = []
	for dataset in dataset_list:
		state_diff = State_Differential(dataset)
		state_diff.check_distinguisher()
		if (state_diff._if_distinguisher):
			distinguisher_list.append(state_diff)
	
	return distinguisher_list
		
def print_heading():
	print("							#############################")
	print("							#      DFATool-v1.1         #")
	print("							#                           #")
	print("							# Author: Sayandeep Saha    #")
	print("							#                           #")
	print("							# Last Modified: 9/12/2017  #")
	print("							#############################")			

def pause():
	programPause = input("Press the <ENTER> key to continue...")

			 
if __name__ == '__main__':
	
	ip_folder_1 = os.environ.get('INPUTDIR')
	ip_folder_2 = os.environ.get('OUTPUTDIR')
	
	dataset_list = read_input(ip_folder_1, ip_folder_2)
	distinguisher_list = identify_distinguishers(dataset_list)

